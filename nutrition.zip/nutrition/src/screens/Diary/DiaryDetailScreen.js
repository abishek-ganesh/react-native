import React from 'react';
import { ScrollView, Image, View, Text, StyleSheet } from 'react-native';
import { useSelector } from 'react-redux';
import Colors from '../../constants/colors';
import Spacer from '../../components/UI/Spacer';
import { HeaderButtons, Item } from 'react-navigation-header-buttons';
import HeaderButtonFA from '../../components/UI/Buttons/HeaderButtonFA';

const DiaryDetailScreen = props => {
  const mealId = props.navigation.getParam('mealId');
  const selectedMeal = useSelector(state =>
    state.diaryMeals.userDiaryMeals.find(meal => meal.id === mealId)
  );

  return (
    <View style={styles.container}>
        <Image style={styles.image} source={{ uri: selectedMeal.image }} />
        <Spacer />
        <Text style={styles.label}>Foods:</Text>
        {selectedMeal.foodTags ? <View>{selectedMeal.foodTags.map(f => <Text key={f}>{f}</Text>)}</View> : <View></View>}

        <Spacer />
        {selectedMeal.description ? <Text style={styles.label}>Description: {selectedMeal.description}</Text>: <View></View>}
        <Spacer />
        <Text style={styles.label}>Ratings</Text>
        {selectedMeal.overallRating ? <Text>Overall Rating: {selectedMeal.overallRating}</Text>: <View></View>}
        {selectedMeal.costRating ? <Text>Cost Rating: {selectedMeal.costRating}</Text>: <View></View>}
        {selectedMeal.tasteRating ? <Text>Taste Rating: {selectedMeal.tasteRating}</Text>: <View></View>}
        {selectedMeal.healthRating ? <Text>Health Rating: {selectedMeal.healthRating}</Text>: <View></View>}
        {selectedMeal.timeRating ? <Text>Time Rating: {selectedMeal.timeRating}</Text>: <View></View>}



    </View>
  );
};

DiaryDetailScreen.navigationOptions = navData => {
    return {
        headerTitle: navData.navigation.getParam('mealDate')
          ? navData.navigation.getParam('mealDate')
          : 'Meal Details',
    };
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
    },
    label: {
        fontSize: 18,
        marginBottom: 5
    },
    image: {
        height: '35%',
        minHeight: 300,
        width: '100%',
        backgroundColor: '#ccc'
      },
    addressContainer: {
        padding: 20
      },
    address: {
        color: Colors.primary,
        textAlign: 'center'
      },
});

export default DiaryDetailScreen;
