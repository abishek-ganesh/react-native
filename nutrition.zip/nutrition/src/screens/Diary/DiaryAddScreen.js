import React, { useState, useCallback, useReducer, useEffect } from 'react';
import { ScrollView, View, Text, TextInput, StyleSheet, KeyboardAvoidingView } from 'react-native';
import { Button } from 'react-native-elements';
import Input from '../../components/UI/Input';
import Spacer from '../../components/UI/Spacer';
import Colors from '../../constants/colors';
import LocationPicker from "../../components/Diary/LocationPicker";
import * as diaryActions from '../../store/actions/diary';
import ImagePicker from '../../components/Diary/ImagePicker';
import { useSelector, useDispatch } from 'react-redux';
import moment from 'moment';
import DatePicker from "react-native-datepicker";
import { Rating, AirbnbRating } from 'react-native-ratings';
import {backgroundColor} from "react-native-calendars/src/style";
import { FontAwesome } from '@expo/vector-icons';

const FORM_INPUT_UPDATE = 'FORM_INPUT_UPDATE';
const DOLLAR_SIGN = require('../../constants/dollar.png');
const SMILE_ICON = require('../../constants/smile.png');
const CLOCK_ICON = require('../../constants/clock.png');


const DiaryAddScreen = props => {
  const [description, setDescription] = useState('');
  const [mealDate, setMealDate] = useState(moment().format("MMMM DD YYYY"));
  const [overallRating, setOverallRating] = useState();
  const [costRating, setCostRating] = useState();
  const [tasteRating, setTasteRating] = useState();
  const [healthRating, setHealthRating] = useState();
  const [timeRating, setTimeRating] = useState();
  const [location, setLocation] = useState();
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
  const [selectedImage, setSelectedImage] = useState();
  const [food, setFood] = useState();
  const [foods, setFoods] = useState([]);
  const dateCreated = moment();


  const dispatch = useDispatch();

  const descriptionChangeHandler = text => {
    // add validation here
    setDescription(text);
  };

  const mealDateChangeHandler = d => { setMealDate(d); };
  const overallRatingChangeHandler = r => { setOverallRating(r); };
  const costRatingChangeHandler = r => { setCostRating(r); };
  const tasteRatingChangeHandler = r => { setTasteRating(r); };
  const healthRatingChangeHandler = r => { setHealthRating(r); };
  const timeRatingChangeHandler = r => { setTimeRating(r); };
  const locationChangeHandler = enteredText => { setLocation(enteredText); };
  const imageTakenHandler = imagePath => { setSelectedImage(imagePath); };
  const foodUpdateHandler = f => { setFood(f); };
  const foodsUpdateHandler = () => {
    setFoods(foods => [...foods, food]);
    setFood('');
  };



  const submitHandler = () => {
    dispatch(diaryActions.addDiaryMeal(description, mealDate, selectedImage, location, foods, overallRating, tasteRating, healthRating, costRating, timeRating, dateCreated));
    props.navigation.navigate('Diary');
  };

  return (
    <KeyboardAvoidingView 
        style={{flex: 1}}
        behavior='padding'
        keyboardVerticalOffset={100}
    >
      <ScrollView>
        <View style={styles.form}>
          <ImagePicker onImageTaken={imageTakenHandler} />
          <Text style={styles.label}>Description</Text>
          <TextInput
            style={styles.textInput}
            onChangeText={descriptionChangeHandler}
            placeholder={'Optional'}
            value={description}
          />
          <Text style={styles.label}>Date</Text>
          <DatePicker
            style={styles.datePickerStyle}
            date={mealDate}
            mode='date'
            format='MMMM DD YYYY'
            maxDate={moment().format("MMMM DD YYYY")}
            confirmBtnText='Confirm'
            cancelBtnText='Cancel'
            customStyles={{
              dateIcon: {
                position: 'absolute',
                left: 0,
                top: 4,
                marginLeft: 0,
              },
              dateInput: {
                marginLeft: 36,
              },
            }}
            onDateChange={mealDateChangeHandler}
          />
          <Text style={styles.label}>Add Food</Text>
          <TextInput
              style={styles.textInput}
              onChangeText={foodUpdateHandler}
              value={food}
          />
          <Button
              title="Add Food Item"
              type='clear'
              color={Colors.primary}
              onPress={foodsUpdateHandler}
          />
          {foods.map(f => <Text key={f}>{f}</Text>)}
          <Text style={styles.label}>Overall Rating</Text>
          <AirbnbRating
              showRating
              count={5}
              defaultRating={0}
              size={25}
              reviews={['1','2','3','4','5']}
              onFinishRating={overallRatingChangeHandler}
          />
          <Text style={styles.label}>Cost Rating</Text>
          <Rating
            showRating
            type='custom'
            ratingImage={DOLLAR_SIGN}
            style={{ paddingVertical: 10 }}
            tintColor={backgroundColor}
            //ratingColor={'#ccc'}
            imageSize={25}
            startingValue={0}
            minValue={1}
            onFinishRating={costRatingChangeHandler}
          />
          <Text style={styles.label}>Taste Rating</Text>
          <Rating
              showRating
              type='custom'
              ratingImage={SMILE_ICON}
              style={{ paddingVertical: 10 }}
              tintColor={backgroundColor}
              //ratingColor={'#ccc'}
              imageSize={25}
              startingValue={0}
              minValue={1}
              onFinishRating={tasteRatingChangeHandler}
          />
          <Text style={styles.label}>Health Rating</Text>
          <Rating
              showRating
              type='heart'
              style={{ paddingVertical: 10 }}
              tintColor={backgroundColor}
              //ratingColor={'#ccc'}
              reviews={["Good", 'Bad', 'sdf', 'dd', 'd']}
              imageSize={25}
              startingValue={0}
              minValue={1}
              onFinishRating={healthRatingChangeHandler}
          />
          <Text style={styles.label}>Time Spent</Text>
          <Rating
              showRating
              type='custom'
              ratingImage={CLOCK_ICON}
              style={{ paddingVertical: 10 }}
              tintColor={backgroundColor}
              //ratingColor={'#ccc'}
              imageSize={25}
              startingValue={0}
              minValue={1}
              onFinishRating={timeRatingChangeHandler}
          />
          <Button
            title="Save Meal"
            type='clear'
            color={Colors.primary}
            onPress={submitHandler}
          />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  form: {
    margin: 30
  },
  label: {
    fontSize: 18,
    marginBottom: 5
  },
  textInput: {
    borderBottomColor: '#ccc',
    borderBottomWidth: 1,
    marginBottom: 15,
    paddingVertical: 4,
    paddingHorizontal: 2
  },
  datePickerStyle: {
    width: 200,
    marginTop: 20,
  },
});

export default DiaryAddScreen;