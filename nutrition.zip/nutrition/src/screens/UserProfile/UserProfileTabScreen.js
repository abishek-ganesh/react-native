import React, { useState } from 'react';
import { View, StyleSheet, Dimensions, StatusBar } from "react-native";
import { TabView, SceneMap } from "react-native-tab-view";
import ProfileViewScreen from '../Profile/ProfileViewScreen';
import GoalsViewScreen from "../Goals/GoalsViewScreen";


// THIS DOESNT WORK when i try to navigate to Add Goal tab. need to figure out a different way

const UserProfileTabScreen = props => {
    const [index, setIndex] = useState(0);
    const [routes] = useState([
        { key: 'profile', title: 'Profile' },
        { key: 'goals', title: 'Goals' },
    ]);

    const Goals = () => (
        <GoalsViewScreen />
    );

    const Profile = () => (
        <ProfileViewScreen {...props} />
    );

    const initialLayout = { width: Dimensions.get('window').width };

    const renderScene = SceneMap({
        profile: Profile,
        goals: Goals,
    });

    return (
        <TabView
            renderScene={renderScene}
            onIndexChange={setIndex}
            navigationState={{ index, routes }}
            initialLayout={initialLayout}
            style={styles.container}
        />
    );
};

const styles = StyleSheet.create({
    container: {
        //marginTop: StatusBar.currentHeight,

    },
    scene: {
        flex: 1,
    },
});

export default UserProfileTabScreen;