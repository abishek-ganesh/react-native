/**
 * Created by admin on 6/21/20.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {View, Text, StyleSheet, FlatList, ActivityIndicator, TextInput} from 'react-native';
import Spacer from '../../components/UI/Spacer';
import { Button } from 'react-native-elements';
import GoalItem from '../../components/Goals/GoalItem';
import Colors from '../../constants/colors';
import { HeaderButtons, Item } from 'react-navigation-header-buttons';
import HeaderButton from '../../components/UI/Buttons/HeaderButtonFeather';
import { useSelector, useDispatch } from 'react-redux';
import * as goalActions from '../../store/actions/goals';
import * as profileActions from "../../store/actions/profile";
import moment from "moment";
import DatePicker from "react-native-datepicker";
import DiaryScreen from "../Diary/DiaryScreen";


const GoalsViewScreen = props => {
    const [isLoading, setIsLoading] = useState(false);
    const [isRefreshing, setIsRefreshing] = useState(false);
    const [error, setError] = useState();
    const goals = useSelector(state => state.goals.userGoals);
    const dispatch = useDispatch();

    const loadGoals = useCallback(async () => {
        setError(null);
        setIsRefreshing(true);
        try {
            await dispatch(goalActions.fetchGoals());
        } catch (err) {
            setError(err.message);
        }
        setIsRefreshing(false);
    }, [dispatch, setIsLoading, setError]);

    useEffect(() => {
        setIsLoading(true);
        loadGoals().then(() => {
            setIsLoading(false);
        });
    }, [dispatch, loadGoals]);

    if (error) {
        return (
            <View style={styles.centered}>
                <Text>An error occurred!</Text>
                <Button
                    title="Try again"
                    onPress={loadGoals}
                    color={Colors.primary}
                />
            </View>
        );
    }

    const selectItemHandler = (id, goal, status, projectedDateCompleted, importance) => {
        props.navigation.navigate('GoalEdit', {
            goalId: id,
            goal: goal,
            status: status,
            projectedDateCompleted: projectedDateCompleted,
            importance: importance
        });
    };

    if (isLoading) {
        return (<View style={styles.centered}><ActivityIndicator size='large' color={Colors.primary} /></View>);
    }

    if (!isLoading && goals.length === 0) {
        return (
            <View style={styles.centered}>
                <Button
                    title='Add a new Goal'
                    onPress={() => {props.navigation.navigate('GoalEdit')}}
                />
            </View>
        );
    }

    return (
        <View style={styles.screen}>
            <FlatList
                onRefresh={loadGoals}
                refreshing={isRefreshing}
                data={goals}
                keyExtractor={item => item.id}
                renderItem={itemData =>
                    <View style={styles.goal}>
                        <GoalItem
                            id={itemData.item.id}
                            goal={itemData.item.goal}
                            status={itemData.item.status}
                            projectedDateCompleted={itemData.item.projectedDateCompleted}
                            importance={itemData.item.importance}
                            onSelect={() => {
                                selectItemHandler(
                                    itemData.item.id,
                                    itemData.item.goal,
                                    itemData.item.status,
                                    itemData.item.projectedDateCompleted,
                                    itemData.item.importance
                                );
                            }}
                            onRemove={() => {
                                dispatch(goalActions.deleteGoal(itemData.item.id));
                            }}
                        />
                    </View>
                }
            />
            <Button
                title="Add New Goal"
                type='clear'
                onPress={() => {props.navigation.navigate('GoalEdit')}}
            />
            <Spacer />
        </View>
    );
};

GoalsViewScreen.navigationOptions = (navigationData) => {
    return {
        headerRight: () => (
            <HeaderButtons HeaderButtonComponent={HeaderButton}>
                <Item
                    title="Add Goal"
                    iconName='plus'
                    onPress={() => {navigationData.navigation.navigate('GoalEdit')}}
                />
            </HeaderButtons>
        ),
    };
};

const styles = StyleSheet.create({
    screen : {
        flex: 1,
        marginTop: 20,
    },
    centered: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
    datePickerStyle: {
        width: 200,
        marginTop: 20,
    },
    goal: {
        flexDirection: 'row',
        flex: 1

    },
    title: {
        fontSize: 26,
        marginVertical: 5
    },
});

export default GoalsViewScreen;