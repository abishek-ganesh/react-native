/**
 * Created by admin on 6/21/20.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {View, Text, StyleSheet, ScrollView, ActivityIndicator, TextInput, Platform, Image} from 'react-native';
import Spacer from '../../components/UI/Spacer';
import { Button } from 'react-native-elements';
import Colors from '../../constants/colors';
import { HeaderButtons, Item } from 'react-navigation-header-buttons';
import HeaderButton from '../../components/UI/Buttons/HeaderButtonFeather';
import { useSelector, useDispatch } from 'react-redux';
import * as profileActions from "../../store/actions/profile";
import moment from "moment";
import MealItem from "../../components/Diary/MealItem";
import DiaryDetailScreen from "../Diary/DiaryDetailScreen";


const ProfileViewScreen = props => {
    const [isLoading, setIsLoading] = useState(false);
    const [isRefreshing, setIsRefreshing] = useState(false);
    const [error, setError] = useState();
    const userId = useSelector(state => state.auth.userId);
    const profile = useSelector(state => state.profile.userProfile.find(prof => prof.ownerId === userId));
    console.log('profile', profile);
    const dispatch = useDispatch();

    const loadProfile = useCallback(async () => {
        setError(null);
        setIsRefreshing(true);
        try {
            await dispatch(profileActions.fetchProfile());
        } catch (err) {
            setError(err.message);
        }
        setIsRefreshing(false);
    }, [dispatch, setIsLoading, setError]);


    useEffect(() => {
        setIsLoading(true);
        loadProfile().then(() => {
            setIsLoading(false);
        });
    },[dispatch, loadProfile]);

    if (error) {
        return (
            <View style={styles.centered}>
                <Text>An error occurred!</Text>
                <Button
                    title="Try again"
                    onPress={loadProfile}
                    color={Colors.primary}
                />
            </View>
        );
    }

    if (isLoading) {
        return (<View style={styles.centered}><ActivityIndicator size='large' color={Colors.primary} /></View>);
    }

    const selectProfileHandler = (id) => {
        props.navigation.navigate('ProfileEdit', {
            profileId: id
        });
    };


    return (
        <View style={styles.container}>
            <View style={styles.section}>
                <Image style={styles.image} source={profile ? { uri: profile.profileImage } : { uri: 'https://reactnative.dev/img/tiny_logo.png' }} />
                <View style={styles.topright}>
                    <Text style={{ alignSelf: 'center', fontSize: 22 }}>{profile ? profile.fName : ''} {profile ? profile.mName : ''} {profile ? profile.lName : ''}</Text>
                    <Text style={{ alignSelf: 'center', fontSize: 17 }}>Username: {profile ? profile.username : ''}</Text>
                </View>
            </View>
            <View style={styles.section}>
                <Text style={styles.info}>Age: {profile ? moment().diff(profile.dob, 'years') : ''}</Text>
                <Text style={styles.info}>Gender: {profile ? profile.gender : ''}</Text>
            </View>
            <View style={styles.section}>
                <Text style={styles.info}>Height: {profile ? profile.height : ''}</Text>
                <Text style={styles.info}>Weight: {profile ? profile.weight : ''}</Text>
            </View>
            <View style={styles.section}>
                <Text style={styles.info}>Location: {profile ? profile.currentCity : ''}</Text>
            </View>
            <Button
                title="Edit Profile"
                type='clear'
                onPress={() => {
                    selectProfileHandler(
                        profile.id
                    );
                }}
            />
        </View>
    );
};


const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginVertical: 20,
        marginHorizontal: 10,
    },
    section: {
        flex: 1,
        flexDirection: 'row',
    },
    topright: {
        flex: 1,
        justifyContent: 'center',
        marginTop: -30,
    },
    info: {
        flex: 1,
        fontSize: 20,
        alignSelf: 'center',
    },
    centered: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
    datePickerStyle: {
        width: 200,
        marginTop: 20,
    },
    image: {
        width: 100,
        height: 100,
        margin: 10,
        borderRadius: 50,
        backgroundColor: '#ccc',
        borderColor: 'black',
        borderWidth: 1,
    },
});

export default ProfileViewScreen;