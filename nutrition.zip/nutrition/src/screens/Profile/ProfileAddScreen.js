/**
 * Created by admin on 6/21/20.
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
    View,
    Text,
    StyleSheet,
    FlatList,
    ActivityIndicator,
    TextInput,
    Platform,
    ScrollView,
    KeyboardAvoidingView
} from 'react-native';
import Spacer from '../../components/UI/Spacer';
import { Button } from 'react-native-elements';
import GoalItem from '../../components/Goals/GoalItem';
import Colors from '../../constants/colors';
import { HeaderButtons, Item } from 'react-navigation-header-buttons';
import HeaderButton from '../../components/UI/Buttons/HeaderButtonFeather';
import { useSelector, useDispatch } from 'react-redux';
import * as profileActions from "../../store/actions/profile";
import moment from "moment";


const ProfileAddScreen = props => {
    const [fName, setFName] = useState();
    const [mName, setMName] = useState();
    const [lName, setLName] = useState();
    const [username, setUsername] = useState();
    const [email, setEmail] = useState();
    const [dob, setDOB] = useState();
    const [gender, setGender] = useState();
    const [height, setHeight] = useState();
    const [weight, setWeight] = useState();
    const [profileImage, setProfileImage] = useState();
    const [currentCity, setCurrentCity] = useState();
    const [allergy, setAllergy] = useState();
    const [allergies, setAllergies] = useState([]);
    const [foodLoved, setFoodLoved] = useState();
    const [foodsLoved, setFoodsLoved] = useState([]);
    const [foodDisliked, setFoodDisliked] = useState();
    const [foodsDisliked, setFoodsDisliked] = useState([]);
    const [dateCreated, setDateCreated] = useState(moment()); // set to Today
    const [active, setActive] = useState(true);
    const [showDTP, setShowDTP] = useState(false);
    const [modeDTP, setModeDTP] = useState('date');

    const dispatch = useDispatch();

    const fNameInputHandler = enteredText => {setFName(enteredText);};
    const mNameInputHandler = enteredText => {setMName(enteredText);};
    const lNameInputHandler = enteredText => {setLName(enteredText);};
    const usernameInputHandler = enteredText => {setUsername(enteredText);};
    const emailInputHandler = enteredText => {setEmail(enteredText);};
    const dobInputHandler = enteredDate => {setDOB(enteredDate);};
    const genderInputHandler = selectedOption => {setGender(selectedOption);};
    const heightInputHandler = selectedOption => {setHeight(selectedOption);};
    const weightInputHandler = selectedOption => {setWeight(selectedOption);};
    const profileImageInputHandler = imagePath => {setProfileImage(imagePath);};
    const currentCityInputHandler = enteredText => {setCurrentCity(enteredText);};
    const allergyInputHandler = enteredText => {setAllergy(enteredText);};
    const allergiesInputHandler = () => {
        setAllergies(allergies => [...allergies, allergy]);
        setAllergy('');
    };
    const foodLovedInputHandler = enteredText => {setFoodLoved(enteredText);};
    const foodsLovedInputHandler = () => {
        setFoodsLoved(foodsLoved => [...foodsLoved, foodLoved]);
        setFoodLoved('');
    };
    const foodDislikedInputHandler = enteredText => {setFoodDisliked(enteredText);};
    const foodsDislikedInputHandler = () => {
        setFoodsDisliked(foodsDisliked => [...foodsDisliked, foodDisliked]);
        setFoodDisliked('');
    };

    const showMode = (currentMode) => {
        setShowDTP(true);
        setModeDTP(currentMode);
    };
    const showDatePicker = () => {
        showMode('date');
    };
    const showTimePicker = () => {
        showMode('time');
    };
    const onDateChange = (event, selectedDate) => {
        const currentDate = selectedDate || dob;
        //setShowDTP(Platform.OS == 'ios');
        setDOB(currentDate);
    };

    const submitHandler = () => {
        dispatch(profileActions.createProfile(fName, mName, lName, username, email, dob, gender, height, weight, profileImage, currentCity, allergies, foodsLoved, foodsDisliked, dateCreated, active));
        console.log('profile submitted');

        props.navigation.navigate('Diary');
    };


    return (
        <KeyboardAvoidingView
            style={{flex: 1}}
            behavior='padding'
            keyboardVerticalOffset={100}
        >
            <ScrollView>
                <View style={{flex: 1}}>
                    <Text style={{ fontSize: 20 }}>First Name:</Text>
                    <TextInput
                        placeholder='First name...'
                        autoCorrect={false}
                        style={styles.input}
                        onChangeText={fNameInputHandler}
                        value={fName}
                    />
                    <Spacer />
                    <Text style={{ fontSize: 20 }}>Middle Name:</Text>
                    <TextInput
                        placeholder='Middle name...'
                        autoCorrect={false}
                        style={styles.input}
                        onChangeText={mNameInputHandler}
                        value={mName}
                    />
                    <Spacer />
                    <Text style={{ fontSize: 20 }}>Last Name:</Text>
                    <TextInput
                        placeholder='Last name...'
                        autoCorrect={false}
                        style={styles.input}
                        onChangeText={lNameInputHandler}
                        value={lName}
                    />
                    <Spacer />
                    <Text style={{ fontSize: 20 }}>Username:</Text>
                    <TextInput
                        placeholder='Username...'
                        autoCorrect={false}
                        style={styles.input}
                        onChangeText={usernameInputHandler}
                        value={username}
                    />
                    <Spacer />
                    <Text style={{ fontSize: 20 }}>Dob:</Text>
                    <TextInput
                        placeholder='Birthday...'
                        autoCorrect={false}
                        style={styles.input}
                        onChangeText={dobInputHandler}
                        value={dob}
                    />
                    <Spacer />
                    <Text style={{ fontSize: 20 }}>Gender:</Text>
                    <TextInput
                        placeholder='Gender...'
                        autoCorrect={false}
                        style={styles.input}
                        onChangeText={genderInputHandler}
                        value={gender}
                    />
                    <Spacer />
                    <Text style={{ fontSize: 20 }}>Height:</Text>
                    <TextInput
                        placeholder='Height...'
                        autoCorrect={false}
                        style={styles.input}
                        onChangeText={heightInputHandler}
                        value={height}
                    />
                    <Spacer />
                    <Text style={{ fontSize: 20 }}>Weight:</Text>
                    <TextInput
                        placeholder='Weight...'
                        autoCorrect={false}
                        style={styles.input}
                        onChangeText={weightInputHandler}
                        value={weight}
                    />
                    <Spacer />
                    <Text style={{ fontSize: 20 }}>Current City:</Text>
                    <TextInput
                        placeholder='Current city...'
                        autoCorrect={false}
                        style={styles.input}
                        onChangeText={currentCityInputHandler}
                        value={currentCity}
                    />
                    <Spacer />
                    <Text style={{ fontSize: 20 }}>Allergies:</Text>
                    <TextInput
                        placeholder='Allergies...'
                        autoCorrect={false}
                        style={styles.input}
                        onChangeText={allergyInputHandler}
                        value={allergies}
                    />
                    <Spacer />
                    <Text style={{ fontSize: 20 }}>Foods Loved:</Text>
                    <TextInput
                        placeholder='Foods loved...'
                        autoCorrect={false}
                        style={styles.input}
                        onChangeText={foodLovedInputHandler}
                        value={foodsLoved}
                    />
                    <Spacer />
                    <Text style={{ fontSize: 20 }}>Foods Disliked:</Text>
                    <TextInput
                        placeholder='Foods disliked...'
                        autoCorrect={false}
                        style={styles.input}
                        onChangeText={foodDislikedInputHandler}
                        value={foodsDisliked}
                    />
                    <Spacer />
                    <Text style={{ fontSize: 20 }}>Profile Image:</Text>
                    <TextInput
                        placeholder='Profile Image...'
                        autoCorrect={false}
                        style={styles.input}
                        onChangeText={profileImageInputHandler}
                        value={profileImage}
                    />
                    <Spacer />
                    <Button
                        title='Confirm'
                        color={Colors.primary}
                        onPress={submitHandler}
                    />
                    <Spacer />
                </View>
            </ScrollView>
        </KeyboardAvoidingView>
    );
};



const styles = StyleSheet.create({
    centered: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
    datePickerStyle: {
        width: 200,
        marginTop: 20,
    },
});

export default ProfileAddScreen;