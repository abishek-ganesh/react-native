/**
 * Created by admin on 6/21/20.
 */
import React, { useState, useReducer, useEffect, useCallback } from 'react';
import {
    View,
    Text,
    StyleSheet,
    FlatList,
    ActivityIndicator,
    TextInput,
    Platform,
    Alert,
    KeyboardAvoidingView
} from 'react-native';
import Spacer from '../../components/UI/Spacer';
import { Button } from 'react-native-elements';
import Input from '../../components/UI/Input';
import Colors from '../../constants/colors';
import { HeaderButtons, Item } from 'react-navigation-header-buttons';
import HeaderButton from '../../components/UI/Buttons/HeaderButtonFeather';
import { useSelector, useDispatch } from 'react-redux';
import * as profileActions from "../../store/actions/profile";
import moment from "moment";
import DatePicker from "react-native-datepicker";
import DateTimePicker from '@react-native-community/datetimepicker';
import {Picker} from '@react-native-picker/picker';


// HERE I WANT TO: only be able to edit the key profile info (name, email)
// other fields - use a ProfileEdit component [need to create] to update via modal

const ProfileEditScreen = props => {
    const profileId = props.navigation.getParam('profileId');
    const editedProfile = useSelector( state =>
        state.profile.userProfile.find(profile => profile.id === profileId)
    );
    console.log('Edited Profile', !!editedProfile, editedProfile);

    const [fName, setFName] = useState(editedProfile.fName);
    const [mName, setMName] = useState(editedProfile.mName);
    const [lName, setLName] = useState(editedProfile.lName);
    const [username, setUsername] = useState(editedProfile.username);
    const [dob, setDOB] = useState(moment(editedProfile.dob));
    const [gender, setGender] = useState(editedProfile.gender);
    const [height, setHeight] = useState();
    const [weight, setWeight] = useState();
    const [profileImage, setProfileImage] = useState();
    const [currentCity, setCurrentCity] = useState(editedProfile.currentCity);
    const [allergy, setAllergy] = useState();
    const [allergies, setAllergies] = useState([]);
    const [foodLoved, setFoodLoved] = useState();
    const [foodsLoved, setFoodsLoved] = useState([]);
    const [foodDisliked, setFoodDisliked] = useState();
    const [foodsDisliked, setFoodsDisliked] = useState([]);
    const [active, setActive] = useState(true);
    const [showDTP, setShowDTP] = useState(false);
    const [modeDTP, setModeDTP] = useState('date');

    const dispatch = useDispatch();

    const fNameInputHandler = enteredText => {setFName(enteredText)};
    const mNameInputHandler = enteredText => {setMName(enteredText)};
    const lNameInputHandler = enteredText => {setLName(enteredText)};
    const usernameInputHandler = enteredText => {setUsername(enteredText)};
    const dobInputHandler = d => {setDOB(d);};
    const genderInputHandler = selectedOption => {setGender(selectedOption);};
    const currentCityInputHandler = selectedOption => {setCurrentCity(selectedOption);};
    const heightInputHandler = selectedOption => {setHeight(selectedOption);};
    const weightInputHandler = selectedOption => {setWeight(selectedOption);};
    const allergyInputHandler = enteredText => { setAllergy(enteredText); };
    const allergiesInputHandler = () => {
        setAllergies(allergies => [...allergies, allergy]);
        setAllergy('');
    };

    const submitHandler = () => {
        dispatch(profileActions.updateProfile(profileId, fName, mName, lName, username, editedProfile.email, dob, gender, height, weight, profileImage, currentCity, allergies, foodsLoved, foodsDisliked, active));
        console.log('profile submitted');
        props.navigation.goBack();
    };

    /*useEffect(() => {
        props.navigation.setParams({ submit: submitHandler });
    }, [submitHandler]);*/


    return (
        <KeyboardAvoidingView
            style={styles.profPage}
            behavior='padding'
            keyboardVerticalOffset={100}
        >
            <View style={styles.row}>
                <View style={styles.rowItem}>
                    <Text style={styles.label}>First</Text>
                    <TextInput
                        style={styles.input}
                        onChangeText={fNameInputHandler}
                        placeholder={'First'}
                        value={fName}
                    />
                </View>
                <View style={styles.rowItem}>
                    <Text style={styles.label}>Middle</Text>
                    <TextInput
                        style={styles.input}
                        onChangeText={mNameInputHandler}
                        placeholder={'Middle'}
                        value={mName}
                    />
                </View>
                <View style={styles.rowItem}>
                    <Text style={styles.label}>Last</Text>
                    <TextInput
                        style={styles.input}
                        onChangeText={lNameInputHandler}
                        placeholder={'Last'}
                        value={lName}
                    />
                </View>
            </View>

            <View>
                <Text style={styles.label}>Username</Text>
                <TextInput
                    style={styles.input}
                    onChangeText={usernameInputHandler}
                    placeholder={'Username'}
                    value={username}
                />
                <Spacer />
                <Text style={styles.label}>Current City</Text>
                <TextInput
                    style={styles.input}
                    onChangeText={currentCityInputHandler}
                    placeholder={'Location'}
                    value={currentCity}
                />
            </View>
            <View style={styles.row}>
                <View style={styles.rowItem}>
                    <Text style={styles.label}>Sex</Text>
                    <Picker
                        selectedValue={gender}
                        style={styles.pickerStyle}
                        onValueChange={genderInputHandler}
                    >
                        <Picker.Item label="Male" value="Male" />
                        <Picker.Item label="Female" value="Female" />
                        <Picker.Item label="Intersex" value="Intersex" />
                    </Picker>
                </View>
                <View style={styles.rowItem}>
                    <Text style={styles.label}>Birthday</Text>
                    <DatePicker
                        style={styles.datePickerStyle}
                        date={dob}
                        mode='date'
                        placeholder={dob}
                        format='MMMM DD YYYY'
                        maxDate={moment().subtract(13, 'years').format("MMMM DD YYYY")}
                        confirmBtnText='Confirm'
                        cancelBtnText='Cancel'
                        customStyles={{
                            dateIcon: {
                                position: 'absolute',
                                left: 0,
                                top: 4,
                                marginLeft: 0,
                            },
                            dateInput: {
                                marginLeft: 36,
                            },
                        }}
                        onDateChange={dobInputHandler}
                    />
                </View>
            </View>
            <View>
                <Button
                    title="Save Profile"
                    type='clear'
                    onPress={submitHandler}
                />
            </View>
        </KeyboardAvoidingView>

    );
};

ProfileEditScreen.navigationOptions = navData => {
    const submitFn = navData.navigation.getParam('submit');
    return {
        headerTitle: 'Edit Profile',
        headerRight: () => (
            <HeaderButtons HeaderButtonComponent={HeaderButton}>
                <Item
                    title="Save"
                    iconName='check'
                    onPress={submitFn}
                />
            </HeaderButtons>
        )
    };
};


const styles = StyleSheet.create({
    profPage: {
        flex: 1,
        marginVertical: 60,
        marginHorizontal: 10,
        justifyContent: 'space-between',
    },
    centered: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
    row: {
        flexDirection: 'row',
    },
    rowItem : {
        flex: 1,
    },
    form: {
        flex: 1,
        margin: 20
    },
    label: {
        marginVertical: 8
    },
    pickerStyle: {
        width: 150,
        height: 50,
        marginTop: Platform.OS === 'android' ? -10 : -80,
    },
    datePickerStyle: {
        width: 200,
        height: 50,
        marginTop: 20,
    },
    input: {
        paddingHorizontal: 2,
        paddingVertical: 5,
        borderBottomColor: '#ccc',
        borderBottomWidth: 1
    },
});

export default ProfileEditScreen;