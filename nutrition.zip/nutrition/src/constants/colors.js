/**
 * Created by admin on 6/24/20.
 */
export default {
    primary: 'rgba(3, 202, 252, 1.0)',
    secondary: '#03cafc',
    tertiary: '#f7ffff',
    primaryTransparent: 'rgba(3, 202, 252, 0.05)'
};