/**
 * Created by admin on 6/23/20.
 */
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TouchableNativeFeedback, Platform } from 'react-native';
import Spacer from '../UI/Spacer';
import Card from '../UI/Card';
import Colors from '../../constants/colors';
import { HeaderButton } from 'react-navigation-header-buttons';
import { MaterialCommunityIcons } from '@expo/vector-icons';

const GoalItem = props => {
    let TouchableCmp = TouchableOpacity;

    if (Platform.OS === 'android' && Platform.Version >= 21) {
        TouchableCmp = TouchableNativeFeedback;
    }

    return (
        <View style={styles.container}>
            <View style={styles.details}>
                <Text style={styles.goal}>{props.goal}</Text>
                <Spacer />
                <Text style={styles.importance}>{props.importance} importance</Text>
            </View>
            <View style={styles.days}>
                <Text style={styles.dayNum}>38</Text>
                <Text>Days</Text>
            </View>
            <View style={styles.editor}>
                <TouchableCmp onPress={props.onSelect} useForeground>
                    <MaterialCommunityIcons name="pencil-outline" size={20} color={'#A9A9A9'}/>
                </TouchableCmp>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        borderBottomColor: '#D9D6CF',
        borderBottomWidth: 1,
        flexDirection: 'row',
        flex: 1,
        justifyContent: 'space-between',
        marginHorizontal: 20,
    },
    details: {
        alignItems: 'center',
        paddingVertical: 10,
        marginLeft: 10,
        flex: 3,
    },
    goal: {
        fontSize: 26,
        marginVertical: 2
    },
    editor: {
        marginTop: 15,
        marginHorizontal: 5,
    },
    days: {
        alignItems: 'center',
        paddingVertical: 50,
        marginHorizontal: 10,
        flex: 1,
    },
    dayNum: {
        fontSize: 18,
    },
    importance: {
        fontSize: 18,
        marginVertical: 2
    },
    status: {
        fontSize: 24,
        marginVertical: 2,
        color: Colors.primary,
        fontWeight: 'bold'
    },
});

export default GoalItem;