import { ADD_DIARY_MEAL, SET_DIARY_MEALS, SET_DAILY_DIARY_MEALS, UPDATE_DIARY_MEAL, DELETE_DIARY_MEAL } from '../actions/diary';
import DiaryMeal from '../../models/diaryEntry';

const initialState = {
    userDiaryMeals: [],
    userDailyDiaryMeals: []
};

export default (state = initialState, action) => {
    switch (action.type) {
        case SET_DIARY_MEALS: 
            return {
                userDiaryMeals: action.userDiaryMeals
            };
        case ADD_DIARY_MEAL:
            const newDiaryMeal = new DiaryMeal(
                action.diaryMealData.id,
                action.diaryMealData.ownerId,
                action.diaryMealData.description,
                action.diaryMealData.date,
                action.diaryMealData.image
            );
            return {
                ...state,
                userDiaryMeals: state.userDailyDiaryMeals.concat(newDiaryMeal)
            };  
        case UPDATE_DIARY_MEAL:
            const diaryMealIndex = state.userDiaryMeals.findIndex(
                meal => meal.id === action.dmid
            );
            const updatedDiaryMeal = new DiaryMeal(
                action.dmid,
                state.userDiaryMeals[diaryMealIndex].userId,
                action.diaryMealData.description,
                action.diaryMealData.date,
                action.diaryMealData.image
            );
            const updatedUserDiaryMeals = [...state.userDiaryMeals];
            updatedUserDiaryMeals[diaryMealIndex] = updatedDiaryMeal;
            return {
                ...state,
                userDiaryMeals: updatedUserDiaryMeals
            };
        case DELETE_DIARY_MEAL:
            return {
                ...state,
                userDiaryMeals: state.userDiaryMeals.filter(
                    meal => meal.id !== action.dmid
                )
            };    
    }
    return state;
};