import moment from 'moment';

class Goal {
    constructor(id, ownerId, goal, status, projectedDateCompleted, importance, dateCreated, completed, dateCompleted) {
        this.id = id;
        this.ownerId = ownerId;
        this.goal = goal;
        this.status = status;
        this.projectedDateCompleted = projectedDateCompleted;
        this.importance = importance;
        this.dateCreated = dateCreated;
        this.completed = completed;
        this.dateCompleted = dateCompleted;
    }

    get readableProjectedDateCompleted() {
        return moment(this.projectedDateCompleted).format('MMMM DD YYYY');
    }
    get readableDateCreated() {
        return moment(this.dateCreated).format('MMMM DD YYYY');
    }
    get readableDateCompleted() {
        return moment(this.dateCompleted).format('MMMM DD YYYY');
    }
}

export default Goal;