import moment from 'moment';

class Profile {
    constructor(id, ownerId, fName, mName, lName, username, email, dob, gender, height, weight, profileImage, currentCity, allergies, foodsLoved, foodsDisliked, dateCreated, active) {
        this.id = id;
        this.ownerId = ownerId;
        this.fName = fName;
        this.mName = mName;
        this.lName = lName;
        this.username = username;
        this.email = email;
        this.dob = dob;
        this.gender = gender;
        this.height = height;
        this.weight = weight;
        this.profileImage = profileImage;
        this.currentCity = currentCity;
        this.allergies = allergies;
        this.foodsLoved = foodsLoved;
        this.foodsDisliked = foodsDisliked;
        this.dateCreated = dateCreated;
        this.active = active;
    }

    get readableDob() {
        return moment(this.dob).format('MMMM DD YYYY');
    }
    get readableDateCreated() {
        return moment(this.dateCreated).format('MMMM DD YYYY');
    }
}

export default Profile;