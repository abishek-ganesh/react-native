import moment from 'moment';

class DiaryEntry {
    constructor(id, ownerId, description, mealDate, image, location, foodTags, overallRating, tasteRating, healthRating, costRating, timeRating, dateCreated) {
        this.id = id;
        this.ownerId = ownerId;
        this.description = description;
        this.mealDate = mealDate;
        this.image = image;
        this.location = location;
        this.foodTags = foodTags;
        this.overallRating = overallRating;
        this.tasteRating = tasteRating;
        this.healthRating = healthRating;
        this.costRating = costRating;
        this.timeRating = timeRating;
        this.dateCreated = dateCreated;
    }

    get readableMealDate() {
        return moment(this.mealDate).format('MMMM DD YYYY');
    }
    get readableDateCreated() {
        return moment(this.dateCreated).format('MMMM DD YYYY');
    }
}

export default DiaryEntry;