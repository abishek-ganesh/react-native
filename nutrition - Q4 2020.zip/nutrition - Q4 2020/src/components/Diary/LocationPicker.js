import React, {useState} from 'react';
import { View, Text, ActivityIndicator, Alert, StyleSheet } from 'react-native';
import { Button } from 'react-native-elements';
import Colors from '../../constants/colors';
import * as Location from 'expo-location';
import * as Permissions from 'expo-permissions';

// I dont need this right now. But eventually I will need to pick up user location to find nearby restaurants and locations for them to pick

const LocationPicker = props => {
    const [pickedLocation, setPickedLocation] = useState(); // used in getLocationHandler after getting location
    const [isFetching, setIsFetching] = useState(false); // used for spinner while fetching location in getLocationHandler



    // first get permissions
    const verifyPermissions = async () => {
        const result = await Permissions.askAsync(Permissions.LOCATION);
        if (result.status !== 'granted') {
            Alert.alert('Insufficient permissions.', 'Grant location permissions', [{ text: 'Okay' }]);
            return false;
        }
        return true;
    };

    // get location to pass to OnPress
    const getLocationHandler = async () => {
        // async awaits permission check below
        const hasPermission = await verifyPermissions();
        if (!hasPermission) {
            return;
        }
        // if permitted, await the promise below
        // timeInterval - if we cant get location in 5 sec, we throw an error with rejected promise
        try {
            setIsFetching(true); // turn on spinner
            const location = await Location.getCurrentPositionAsync({timeInterval: 5000});
            //console.log(location);
            setPickedLocation({
                lat: location.coords.latitude,
                lng: location.coords.longitude
            });

        } catch (err) {
            Alert.alert('Could not fetch location', 'Pick location on map', [{text: 'Okay'}]);
        }
        setIsFetching(false); // turn off spinner when done getting location or error
    };

    return (
    <View style={styles.locationPicker}>
        <View style={styles.mapPreview}>
            {/* show spinner while fetching  */}
            {isFetching ? <ActivityIndicator size='large' color={Colors.primary} /> : <Text>No location chosen</Text>}
        </View>
        <Button
            title='Get User Location'
            color={Colors.primary}
            onPress={getLocationHandler}
        />
    </View>
    );
};

const styles = StyleSheet.create({
    locationPicker: {
        marginBottom: 15
    },
    mapPreview: {
        marginBottom: 10,
        width: '100%',
        height: 150,
        borderColor: '#ccc',
        borderWidth: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
});

export default LocationPicker;