import React from 'react';
import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import { createDrawerNavigator, DrawerNavigatorItems } from 'react-navigation-drawer';
import StartupScreen from '../screens/StartupScreen';
import AuthScreen from '../screens/Auth/AuthScreen';
import ProfileViewScreen from '../screens/Profile/ProfileViewScreen';
import ProfileEditScreen from '../screens/Profile/ProfileEditScreen';
import ProfileAddScreen from '../screens/Profile/ProfileAddScreen';
import GoalsViewScreen from '../screens/Goals/GoalsViewScreen';
import GoalEditScreen from '../screens/Goals/GoalEditScreen';
import GoalAddScreen from '../screens/Goals/GoalAddScreen';
import UserProfileTabScreen from "../screens/UserProfile/UserProfileTabScreen";
import DiaryScreen from '../screens/Diary/DiaryScreen';
import DiaryAddScreen from '../screens/Diary/DiaryAddScreen';
import DiaryDetailScreen from '../screens/Diary/DiaryDetailScreen';
import CameraScreen from "../screens/Diary/CameraScreen";
import { Feather, MaterialIcons, MaterialCommunityIcons } from '@expo/vector-icons';
import { View, Platform, Dimensions, SafeAreaView, Button } from 'react-native';
import Colors from '../constants/colors';
import { useDispatch } from 'react-redux';
import * as authActions from '../store/actions/auth';

const defaultNavOptions = {
    headerStyle: {
      backgroundColor: Colors.primary
    },
    headerTintColor: Colors.tertiary,
};

const diaryFlow = createStackNavigator({
    Diary: DiaryScreen,
    DiaryAdd: DiaryAddScreen,
    DiaryDetail: DiaryDetailScreen
},{
    defaultNavigationOptions: ({ navigation }) => ({
        headerTitle: 'Medical Nutrition Therapy App',
        headerStyle: {
            backgroundColor: Colors.primary,
        },
        headerTintColor: Colors.tertiary,
    })
});
diaryFlow.navigationOptions = {
    title: 'Diary',
    tabBarIcon: <MaterialCommunityIcons name="home-heart" size={25}/>,
};

const cameraFlow = createStackNavigator({
    DiaryAdd: DiaryAddScreen,
    Camera: CameraScreen
},{
    defaultNavigationOptions: ({ navigation }) => ({
        headerTitle: 'Add Meal',
        headerStyle: {
            backgroundColor: Colors.primary,
        },
        headerTintColor: Colors.tertiary,
    })
});
cameraFlow.navigationOptions = {
    title: 'Add Meal',
    tabBarIcon: <Feather name="camera" size={25}/>
};

const profileFlow = createStackNavigator({
    ProfileView: ProfileViewScreen,
    TabProfile: UserProfileTabScreen,
    ProfileEdit: ProfileEditScreen,
    ProfileAdd: ProfileAddScreen
},{
    defaultNavigationOptions: ({ navigation }) => ({
        headerTitle: 'My Profile',
        headerStyle: {
            backgroundColor: Colors.primary,
        },
        headerTintColor: Colors.tertiary,
    })
});
profileFlow.navigationOptions = {
    title: 'Profile',
    tabBarIcon: <MaterialIcons name="person-outline" size={25}/>
};

const goalFlow = createStackNavigator({
    GoalsView: GoalsViewScreen,
    GoalEdit: GoalEditScreen,
    GoalAdd: GoalAddScreen
},{
    defaultNavigationOptions: ({ navigation }) => ({
        headerTitle: 'My Goals',
        headerStyle: {
            backgroundColor: Colors.primary,
        },
        headerTintColor: Colors.tertiary,
    })
});
goalFlow.navigationOptions = {
    title: 'Goals',
    tabBarIcon: <MaterialCommunityIcons name="pencil-plus-outline" size={25}/>
};


//-----------------------------------------------------
const homeNavigator = createBottomTabNavigator({
        diaryFlow,
        cameraFlow,
        goalFlow,
        profileFlow
    },{
        tabBarOptions: {
            activeTintColor: Colors.primary,
            activeBackgroundColor: Colors.primaryTransparent,
            showLabel: false,
        },
        initialRouteName: 'diaryFlow'
    }
);

const userNavigator = createDrawerNavigator(
    {
        home: {screen: homeNavigator, navigationOptions: {
            drawerLabel: 'Home'
        }},
    },{
        contentOptions: {
            activeTintColor: Colors.primary,
        },
        contentComponent: props => {
            const dispatch = useDispatch();
            return (
                <View style={{flex: 1, paddingTop: 20}}>
                    <SafeAreaView forceInset={{ top: 'always', horizontal: 'never' }}>
                        <DrawerNavigatorItems {...props} />
                        <Button 
                            title='Logout'
                            color={Colors.primary}
                            onPress={() => {dispatch(authActions.logout());}}
                        />
                    </SafeAreaView>
                </View>
            );
        }
    }
);

const authNavigator = createStackNavigator(
    {Auth: AuthScreen},
    {defaultNavigationOptions: defaultNavOptions}
);

const mainNavigator = createSwitchNavigator({
    Startup: StartupScreen,
    Auth: authNavigator,
    User: userNavigator
},{
    initialRouteName: 'Startup'
}
);



export default createAppContainer(mainNavigator);

