import DiaryMeal from '../../models/diaryEntry';
import * as FileSystem from 'expo-file-system';

export const ADD_DIARY_MEAL = 'ADD_DIARY_MEAL';
export const UPDATE_DIARY_MEAL = 'UPDATE_DIARY_MEAL';
export const DELETE_DIARY_MEAL = 'DELETE_DIARY_MEAL';
export const SET_DIARY_MEALS = 'SET_DIARY_MEALS';
export const SET_DAILY_DIARY_MEALS = 'SET_DAILY_DIARY_MEALS';

export const fetchDiaryMeals = () => {
    return async (dispatch, getState) => {
        const userId = getState().auth.userId;
        try{
            const response = await fetch('https://nutrition-application.firebaseio.com/diary.json');

            if (!response.ok) {
                throw new Error('Something went wrong!');
            }

            const resData = await response.json();
            const loadedDiaryMeals = [];
            for (const key in resData) {
                loadedDiaryMeals.push(
                    new DiaryMeal(
                        key, 
                        resData[key].ownerId,
                        resData[key].description,
                        resData[key].mealDate,
                        resData[key].image,
                        resData[key].location,
                        resData[key].foodTags,
                        resData[key].overallRating,
                        resData[key].tasteRating,
                        resData[key].healthRating,
                        resData[key].costRating,
                        resData[key].timeRating,
                        resData[key].dateCreated
                    )
                );
            }
            dispatch({ type: SET_DIARY_MEALS, diaryMeals: loadedDiaryMeals, userDiaryMeals: loadedDiaryMeals.filter(meal => meal.ownerId === userId) });
        } catch (err) {
            throw err;
        }  
    };
};

export const addDiaryMeal = (description, mealDate, image, location, foodTags, overallRating, tasteRating, healthRating, costRating, timeRating, dateCreated) => {
    return async (dispatch, getState) => {
        const token = getState().auth.token;
        const userId = getState().auth.userId;
        const fileName = image.split('/').pop();
        const newPath = FileSystem.documentDirectory + fileName;

        try {
            await FileSystem.moveAsync({
                from: image,
                to: newPath
            });
        } catch (err) {
            console.log(err);
            throw err;
        }
        

        const response = await fetch(`https://nutrition-application.firebaseio.com/diary.json?auth=${token}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                description,
                mealDate,
                image,
                location,
                foodTags,
                overallRating,
                tasteRating,
                healthRating,
                costRating,
                timeRating,
                dateCreated,
                ownerId: userId // add pushToken after this?
            })
        });

        const resData = await response.json();


        dispatch ({
            type: ADD_DIARY_MEAL,
            diaryMealData: {
                id: resData.name,
                description,
                mealDate, //change this to mealDate.toISOString() ??
                image,
                location,
                foodTags,
                overallRating,
                tasteRating,
                healthRating,
                costRating,
                timeRating,
                dateCreated, // this too
                ownerId: userId
            }
        });
    };
};

export const updateDiaryMeal = (id, description, mealDate, image, location, foodTags, overallRating, tasteRating, healthRating, costRating, timeRating, dateCreated) => {
    return async (dispatch, getState) => {
        const token = getState().auth.token;
        const response = await fetch(
            `https://nutrition-application.firebaseio.com/diary/${id}.json?auth=${token}`,
            {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    description,
                    mealDate,
                    image,
                    location,
                    foodTags,
                    overallRating,
                    tasteRating,
                    healthRating,
                    costRating,
                    timeRating,
                    dateCreated
                })
            }
        );

        if (!response.ok) {
            throw new Error('Something went wrong!');
        }

        dispatch({
            type: UPDATE_DIARY_MEAL,
            dmid: id,
            diaryMealData: {
                description,
                mealDate,
                image,
                location,
                foodTags,
                overallRating,
                tasteRating,
                healthRating,
                costRating,
                timeRating,
                dateCreated
            }
        });
    };
};

export const deleteDiaryMeal = diaryMealId => {
    return async (dispatch, getState) => {
        const token = getState().auth.token;
        const response = await fetch(
            `https://nutrition-application.firebaseio.com/diary/${diaryMealId}.json?auth=${token}`,
            {
                method: 'DELETE'
            }
        );
        
        if (!response.ok) {
            throw new Error('Something went wrong!');
        }

        dispatch({ type: DELETE_DIARY_MEAL, dmid: diaryMealId });
    };
    
};