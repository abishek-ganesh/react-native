import Profile from '../../models/profile';
import * as Notifications from 'expo-notifications';
import * as Permissions from 'expo-permissions';
import * as FileSystem from "expo-file-system";

export const CREATE_PROFILE = 'CREATE_PROFILE';
export const UPDATE_PROFILE = 'UPDATE_PROFILE';
export const DELETE_PROFILE = 'DELETE_PROFILE';
export const SET_PROFILE = 'SET-PROFILE';

export const fetchProfile = () => {
    return async (dispatch, getState) => {
        const userId = getState().auth.userId;
        try{
            const response = await fetch('https://nutrition-application.firebaseio.com/profiles.json');

            if (!response.ok) {
                throw new Error('Something went wrong');
            }
            const resData = await response.json();
            const loadedProfile = [];
            console.log(resData);
            for (const key in resData) {
                loadedProfile.push(
                    new Profile(
                        key,
                        resData[key].ownerId,
                        resData[key].fName,
                        resData[key].mName,
                        resData[key].lName,
                        resData[key].username,
                        resData[key].email,
                        resData[key].dob,
                        resData[key].gender,
                        resData[key].height,
                        resData[key].weight,
                        resData[key].profileImage,
                        resData[key].currentCity,
                        resData[key].allergies,
                        resData[key].foodsLoved,
                        resData[key].foodsDisliked,
                        resData[key].dateCreated,
                        resData[key].active
                    )
                );
            }
            dispatch({ type: SET_PROFILE, profile: loadedProfile, userProfile: loadedProfile.filter(prof => prof.ownerId === userId) });
        } catch (err) {
            throw err;
        }
    };
};

export const createProfile = (fName, mName, lName, username, email, dob, gender, height, weight, profileImage, currentCity, allergies, foodsLoved, foodsDisliked, dateCreated, active) => {
    return async (dispatch, getState) => {
        /*let pushToken;
        let statusObj = await Permissions.getAsync(Permissions.NOTIFICATIONS);
        if (statusObj.status !== 'granted') {
            statusObj = await Permissions.askAsync(Permissions.NOTIFICATIONS);
        }
        if (statusObj.status !== 'granted') {
            pushToken = null;
        } else {
            pushToken = (await Notifications.getExpoPushTokenAsync()).data;
        }*/

        const token = getState().auth.token;
        const userId = getState().auth.userId;
        /*const fileName = profileImage.split('/').pop();
        const newPath = FileSystem.documentDirectory + fileName;

        try {
            await FileSystem.moveAsync({
                from: profileImage,
                to: newPath
            });
        } catch (err) {
            console.log(err);
            throw err;
        }*/

        const response = await fetch(`https://nutrition-application.firebaseio.com/profiles.json?auth=${token}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                fName,
                mName,
                lName,
                username,
                email,
                dob,
                gender,
                height,
                weight,
                profileImage,
                currentCity,
                allergies,
                foodsLoved,
                foodsDisliked,
                dateCreated, // change this like goals actions??
                active,
                ownerId: userId // add pushToken after this?
                //ownerPushToken: pushToken
            })
        });

        const resData = await response.json();

        dispatch({
            type: CREATE_PROFILE,
            profileData: {
                id: resData.name,
                fName,
                mName,
                lName,
                username,
                email,
                dob,
                gender,
                height,
                weight,
                profileImage,
                currentCity,
                allergies,
                foodsLoved,
                foodsDisliked,
                dateCreated,
                active,
                ownerId: userId
            }
        });
    };
};

export const updateProfile = (id, fName, mName, lName, username, email, dob, gender, height, weight, profileImage, currentCity, allergies, foodsLoved, foodsDisliked, active) => {
    return async (dispatch, getState) => {
        const token = getState().auth.token;
        const response = await fetch(
            `https://nutrition-application.firebaseio.com/profiles/${id}.json?auth=${token}`,
            {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    fName,
                    mName,
                    lName,
                    username,
                    email,
                    dob,
                    gender,
                    height,
                    weight,
                    profileImage,
                    currentCity,
                    allergies,
                    foodsLoved,
                    foodsDisliked,
                    active
                })
            }
        );

        if (!response.ok) {
            throw new Error('Something went wrong!');
        }
        dispatch({
            type: UPDATE_PROFILE,
            pid: id,
            profileData: {
                fName,
                mName,
                lName,
                username,
                email,
                dob,
                gender,
                height,
                weight,
                profileImage,
                currentCity,
                allergies,
                foodsLoved,
                foodsDisliked,
                active
            }
        });
    };
};

export const deleteProfile = profileId => {
    return async (dispatch, getState) => {
        const token = getState().auth.token;
        const response = await fetch(
            `https://nutrition-application.firebaseio.com/profiles/${profileId}.json?auth=${token}`,
            {
                method: 'DELETE'
            }
        );

        if (!response.ok) {
            throw new Error('Something went wrong!');
        }

        dispatch({ type: DELETE_PROFILE, pid: profileId });
    };
}