import { AsyncStorage } from 'react-native';

export const AUTHENTICATE = 'AUTHENTICATE';
export const AUTHENTICATE_POSTGRES = 'AUTHENTICATE_POSTGRES';
export const LOGOUT = 'LOGOUT';

let timer;

export const authenticate = (userId, token, expiryTime) => {
    return dispatch => {
        dispatch(setLogoutTimer(expiryTime));
        dispatch({
            type: AUTHENTICATE,
            userId: userId,
            token: token
        });
        
    };
};

export const authenticate_postgres = (myJson) => {
    return dispatch => {
        dispatch({
            type: AUTHENTICATE_POSTGRES,
            myJson
        });
    };
};

export const signup = (email, password) => {
    return async dispatch => {
        const response = await fetch(
            'https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyA_v8KKfhegkG-DI3T3m_zxsxM4E3iOBBc',
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    email: email,
                    password: password,
                    returnSecureToken: true
                })
            }
        );
        
        if (!response.ok) {
            const errorResData = await response.json();
            const errorId = errorResData.error.message;
            let message = 'Something went wrong';
            if (errorId === 'EMAIL_EXISTS') {
                message = 'An account is already created. Try logging in!';
            }
            throw new Error(message);
        }

        const resData = await response.json();
        console.log(resData);
        dispatch(
            authenticate(
                resData.localId, 
                resData.idToken, 
                parseInt(resData.expiresIn) * 1000
            )
        );
        const expirationDate = new Date(new Date().getTime() + parseInt(resData.expiresIn) * 1000);
        saveDataToStorage(resData.idToken, resData.localId, expirationDate);
    };
};

export const login = (email, password) => {
    email = 'admin@admin.com';
    password = 'password';
	//const AUTH_URL='/authenticate/';
	const AUTH_URL='http://localhost:3000/authenticate/';
	
    function loginSuccess (authData) {
		console.log ('loginSuccess authData =');
		console.dir (authData);
        // dispatch({
        //     type: 'LOGIN_SUCCESS',
        //     payload: authData
        // });
    }
    function loginFailed (errorData) {
		console.log ('loginFailed errorData =');
		console.dir (errorData);
		//setAppState({...appState, errorData: errorData});
        // dispatch({
        //     type: 'LOGIN_FAILED',
        //     payload: errorData
        // });
    }
	
    return async dispatch => {
        const response = await fetch(
            'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyA_v8KKfhegkG-DI3T3m_zxsxM4E3iOBBc',
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    email: email,
                    password: password,
                    returnSecureToken: true
                })
            }
        );
        
        if (!response.ok) {
            const errorResData = await response.json();
            const errorId = errorResData.error.message;
            let message = 'Something went wrong';
            if (errorId === 'EMAIL_NOT_FOUND') {
              message = 'No account found. Try signing up!';
            } else if (errorId === 'INVALID_PASSWORD') {
              message = 'Incorrect password. Please try again!';
            }
            throw new Error(message);
          }

        const resData = await response.json();
        console.log(resData);
        /*dispatch(
            authenticate(
                resData.localId, 
                resData.idToken,
                parseInt(resData.expiresIn) * 1000
            )
        );*/
		
		let loginParam={
			email: email,
			password: password
		}
        fetch(AUTH_URL, {
            method: 'POST',
            cache: 'no-cache', // *default, no-cache, reload, force-cache, only-if-cached
            headers: {
                'Accept-Language': 'en-US',
				'Content-Type': 'application/json',
				'Accept': 'application/json'
            },
			body: JSON.stringify(loginParam)
        })
            .then((response) => {
                return response.json();
            }).then(function (myJson) {
                console.log('guestLogin myJson = ');
				console.dir(myJson);
				if ('SUCCESS' == myJson.status) {
					dispatch(
                    authenticate_postgres(
                        myJson.authData
                    )
                    );
				} else {
					console.log('login failed');
				}
                
            })
            .catch((error) => {
                console.log('error   = ');
				console.dir(error);
                loginFailed(error)
            })			
		
        const expirationDate = new Date(new Date().getTime() + parseInt(resData.expiresIn) * 1000);
        saveDataToStorage(resData.idToken, resData.localId, expirationDate);
    };
};

export const logout = () => {
    clearLogoutTimer();
    AsyncStorage.removeItem('userData');
    return { type: LOGOUT };
};

const clearLogoutTimer = () => {
    if (timer) {
        clearTimeout(timer);
    }
};

const setLogoutTimer = expirationTime => {
    return dispatch => {
        timer = setTimeout(() => {
            dispatch(logout());
        }, expirationTime);
    };
};

const saveDataToStorage = (token, userId, expirationDate) => {
    AsyncStorage.setItem(
      'userData',
      JSON.stringify({
        token: token,
        userId: userId,
        expiryDate: expirationDate.toISOString()
      })
    );
  };
  