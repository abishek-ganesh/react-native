import { AUTHENTICATE, LOGOUT, AUTHENTICATE_POSTGRES } from '../actions/auth';

const initialState = {
    token: null,
    userId: null
};

export default (state = initialState, action) => {
    switch (action.type) {
        case AUTHENTICATE:
            return {
                token: action.token,
                userId: action.userId
            };
            break;
        case AUTHENTICATE_POSTGRES:
            console.log('authenticate_postgres action= ');
            console.dir(action);
            return {
                authData: action.myJson
            };
            break;
        case LOGOUT:
            return initialState;
            break;
        default:
            return state;

    }
};