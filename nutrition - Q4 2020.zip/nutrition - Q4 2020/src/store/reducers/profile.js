import Profile from '../../models/profile';
import { SET_PROFILE, CREATE_PROFILE, UPDATE_PROFILE, DELETE_PROFILE } from '../actions/profile';

const initialState = {
    userProfile: []
};

export default (state = initialState, action) => {
    switch (action.type) {
        case SET_PROFILE:
            return {
                userProfile: action.userProfile
            };
        case CREATE_PROFILE:
            const newProfile = new Profile(
                action.profileData.id,
                action.profileData.ownerId,
                action.profileData.fName,
                action.profileData.mName,
                action.profileData.lName,
                action.profileData.username,
                action.profileData.email,
                action.profileData.dob,
                action.profileData.gender,
                action.profileData.height,
                action.profileData.weight,
                action.profileData.profileImage,
                action.profileData.currentCity,
                action.profileData.allergies,
                action.profileData.foodsLoved,
                action.profileData.foodsDisliked,
                action.profileData.dateCreated,
                action.profileData.active
            );
            return {
                ...state,
                userProfile: state.userProfile.concat(newProfile)
            };
        case UPDATE_PROFILE:
            const profileIndex = state.userProfile.findIndex(
                prof => prof.id === action.pid
            );
            const updatedProfile = new Profile(
                action.pid,
                state.userProfile[profileIndex].userId,
                action.profileData.fName,
                action.profileData.mName,
                action.profileData.lName,
                action.profileData.username,
                action.profileData.email,
                action.profileData.dob,
                action.profileData.gender,
                action.profileData.height,
                action.profileData.weight,
                action.profileData.profileImage,
                action.profileData.currentCity,
                action.profileData.allergies,
                action.profileData.foodsLoved,
                action.profileData.foodsDisliked,
                action.profileData.dateCreated,
                action.profileData.active
            );
            const updatedUserProfiles = [...state.userProfile];
            updatedUserProfiles[profileIndex] = updatedProfile;
            return {
                ...state,
                userProfile: updatedUserProfiles
            };
        case DELETE_PROFILE:
            return {
                ...state,
                userProfile: state.userProfile.filter(
                    prof => prof.id !== action.pid
                )
            };
    }
    return state;
};