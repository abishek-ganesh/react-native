import React, { useEffect, useState } from 'react';
import { enableScreens } from 'react-native-screens';
import { createStore, combineReducers, applyMiddleware } from 'redux';
import goalsReducer from './src/store/reducers/goals';
import diaryReducer from './src/store/reducers/diary';
import authReducer from './src/store/reducers/auth';
import profileReducer from './src/store/reducers/profile';
import { Provider } from 'react-redux'; // allows rootReducer store to be provided to the app
import ReduxThunk from 'redux-thunk';
import NavigationContainer from './src/navigation/NavigationContainer';
import * as Notifications from 'expo-notifications';
import * as Permissions from 'expo-permissions';


//lets OS know what to do with notification before presented to user
Notifications.setNotificationHandler({
    handleNotification: async () => {
        return {
            shouldShowAlert: true
        };
    }
});

enableScreens();

const rootReducer = combineReducers({
    goals: goalsReducer,
    diaryMeals: diaryReducer,
    profile: profileReducer,
    auth: authReducer
});

const store = createStore(rootReducer, applyMiddleware(ReduxThunk));

export default function App() {
    const [pushToken, setPushToken] = useState();

    useEffect(() => {
        Permissions.getAsync(Permissions.NOTIFICATIONS).then(statusObj => {
            if (statusObj.status !== 'granted') {
                Permissions.askAsync(Permissions.NOTIFICATIONS);
            }
            return statusObj;
        }).then(statusObj => {
            if (statusObj.status !== 'granted') {
                throw new Error('Permission not granted');
            }
        }).then(() => {
            return Notifications.getExpoPushTokenAsync();
        }).then(response => {
            const token = response.data;
            setPushToken(token);
        })
        .catch((err) => {
            console.log(err);
            return null;
        });
    }, []);

    useEffect(() => {
        const backgroundSubscription = Notifications.addNotificationReceivedListener(response => {
            console.log(response)
        });

        const foregroundSubscription = Notifications.addNotificationReceivedListener(notification => {
            console.log(notification);
        });

        return () => {
            backgroundSubscription.remove();
            foregroundSubscription.remove();
        };
    }, []);

    return (
        <Provider store={store}>
            <NavigationContainer />
        </Provider>
    );
};