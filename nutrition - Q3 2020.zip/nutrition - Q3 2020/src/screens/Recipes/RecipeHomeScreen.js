/**
 * Created by admin on 6/21/20.
 */
import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image, FlatList } from 'react-native';
import Colors from '../../constants/colors';
import Spacer from '../../components/UI/Spacer';
import { Feather } from '@expo/vector-icons';
import { TouchableOpacity } from 'react-native-gesture-handler';
import PrimaryButton from '../../components/UI/Buttons/PrimaryButton';
import { RECIPE_CATEGORIES } from '../../data/recipe-dummy-data';
import RecipeCategoryTile from '../../components/Recipes/RecipeCategoryTile'
import RecipeCategory from '../../models/recipeCategory';
import { HeaderButtons, Item } from 'react-navigation-header-buttons';
import HeaderButton from '../../components/UI/Buttons/HeaderButtonFeather';


const RecipeHomeScreen = props => {

    const renderGridItem = itemData => {
        return (
            <RecipeCategoryTile 
                title={itemData.item.title} 
                image={itemData.item.image} 
                onSelectCategory={() => {
                    props.navigation.navigate(
                        'RecipeCategory', 
                        {categoryId: itemData.item.id}
                    );
                }} 
            />
        );
    };

    return (
        <View>
            <Spacer />
            <View style={{ borderBottomColor: '#D0D0D0', borderBottomWidth: 1, }}>
                <View style={styles.container}>
                    <TouchableOpacity onPress={() => props.navigation.navigate('RecipeFilters')}><Feather name="filter" size={20}/></TouchableOpacity>
                    <Text style={{ fontSize: 20 }}>Time to eat!</Text>
                    <TouchableOpacity onPress={() => props.navigation.navigate('RecipeFavorites')}><Feather name="heart" size={20}/></TouchableOpacity>
                </View>
                <Spacer />
            </View>
            <FlatList 
                data={RECIPE_CATEGORIES}
                renderItem={renderGridItem}
                keyExtractor={item => item.id}
                numColumns={2}
                style={styles.list}
            />
        </View>
    );
};

RecipeHomeScreen.navigationOptions = (navigationData) => {
    return {
        headerLeft: () => (
            <HeaderButtons HeaderButtonComponent={HeaderButton}>
                <Item 
                    title='Menu'
                    iconName='menu'
                    onPress={() => {navigationData.navigation.toggleDrawer()}}
                />
            </HeaderButtons>
        ),
    };
}

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        paddingHorizontal: 15,
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    list: {
        alignSelf: 'center',
    },
});

export default RecipeHomeScreen;