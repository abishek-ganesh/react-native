/**
 * Created by admin on 6/21/20.
 */
import React from 'react';
import { View, Text } from 'react-native';
import { useSelector } from 'react-redux';
import { RECIPE_CATEGORIES } from '../../data/recipe-dummy-data';
import RecipeList from '../../components/Recipes/RecipeList';

const RecipeCategoryScreen = props => {
    

    const catId = props.navigation.getParam('categoryId');

    const availableRecipes = useSelector(state => state.recipes.filteredRecipes);

    const displayedRecipes = availableRecipes.filter(recipe => recipe.categoryIds.indexOf(catId) >= 0);

    if (displayedRecipes.length === 0) {
        return (
            <View><Text>No Recipes found. Check filters.</Text></View>
        );
    }

    return (
        <RecipeList listData={displayedRecipes} navigation={props.navigation} />
    );
};

RecipeCategoryScreen.navigationOptions = (navigationData) => {
    const catId = navigationData.navigation.getParam('categoryId');
    const selectedCategory = RECIPE_CATEGORIES.find(cat => cat.id === catId);

    return {
        headerTitle: selectedCategory.title,
    };
};


export default RecipeCategoryScreen;