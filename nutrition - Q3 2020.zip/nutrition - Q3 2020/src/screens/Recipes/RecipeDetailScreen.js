/**
 * Created by admin on 6/21/20.
 */
import React, { useEffect, useCallback } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { View, Text, StyleSheet, ScrollView, Image } from 'react-native';
import Spacer from '../../components/UI/Spacer';
import { HeaderButtons, Item } from 'react-navigation-header-buttons';
import HeaderButtonFA from '../../components/UI/Buttons/HeaderButtonFA';
import { toggleFavorite } from '../../store/actions/recipes';

const RecipeDetailScreen = props => {
    const recipeId = props.navigation.getParam('recipeId');

    const allRecipes = useSelector(state => state.recipes.recipes);
    const currentMealIsFavorite = useSelector(state => state.recipes.favoriteRecipes.some(recipe => recipe.id === recipeId)); //to fill the heart when selected (in header)

    const selectedRecipe = allRecipes.find(recipe => recipe.id === recipeId);

    const dispatch = useDispatch(); //calls function to dispatch new action of favoriting
    const toggleFavoriteHandler = useCallback(() => {
        dispatch(toggleFavorite(recipeId));
    }, [dispatch, recipeId]);
    // then useEffect to communicate with header
    useEffect(() => {
        props.navigation.setParams({toggleFav: toggleFavoriteHandler});
    }, [toggleFavoriteHandler]);

    //passing currentMealIsFavorite to navigationOptions
    useEffect(() => {
        props.navigation.setParams({isFav: currentMealIsFavorite});
    }, [currentMealIsFavorite]);

    return (
        <ScrollView>
            <Image 
                source={{uri: selectedRecipe.imageUrl}}
                style={styles.image}
                resizeMode="cover"
            />
            <View style={styles.details}>
                <Text style={{ fontSize: 14 }} numberOfLines={1}>{selectedRecipe.title}</Text>
                <Text style={{ fontSize: 12 }}>{selectedRecipe.duration}m  Health Score:{selectedRecipe.healthScore}</Text>
                <Spacer />
                <Text style={{ fontWeight: 'bold' }}>Nutrition Facts:</Text>
                {selectedRecipe.nutritionFacts.map(nutFact => <Text key={nutFact}>{nutFact}</Text>)}
                <Spacer />
                <Text style={{ fontWeight: 'bold' }}>Ingredients:</Text>
                {selectedRecipe.ingredients.map(ingredient => <Text key={ingredient}>{ingredient}</Text>)}
                <Spacer />
                <Text style={{ fontWeight: 'bold' }}>Preparation:</Text>
                {selectedRecipe.instructions.map(instruction => <Text key={instruction}>{instruction}</Text>)}
                <Spacer />
            </View>
            
        </ScrollView>  
    );
};

RecipeDetailScreen.navigationOptions = (navigationData) => {
    //const recipeId = navigationData.navigation.getParam('recipeId');
    const recipeTitle = navigationData.navigation.getParam('recipeTitle');
    const toggleFavorite = navigationData.navigation.getParam('toggleFav');
    const isFavorite = navigationData.navigation.getParam('isFav');
    //const selectedRecipe = RECIPE_DETAILS.find(recipe => recipe.id === recipeId);

    return {
        headerTitle: recipeTitle,
        headerRight: () => (
            <HeaderButtons HeaderButtonComponent={HeaderButtonFA}>
                <Item 
                    title='Favorite'
                    iconName={isFavorite ? 'heart' : 'heart-o'}
                    onPress={toggleFavorite}
                />
            </HeaderButtons>
        )
    };
};

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        paddingHorizontal: 15,
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    image: {
        width: '100%',
        height: 150,
        borderColor: 'black',
        borderWidth: 1,
        marginRight: 2
    },
    imageContainer: {
        flex: 1,
        alignItems: 'center',
    },
    facts:{
        alignSelf: 'center',
        width: "80%",
        borderBottomColor: '#D0D0D0',
        borderBottomWidth: 1,
    },
    details: {
        alignSelf: 'center',
        alignItems: 'center'
    }
});

export default RecipeDetailScreen;