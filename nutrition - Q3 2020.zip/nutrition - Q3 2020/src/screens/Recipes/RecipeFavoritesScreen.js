/**
 * Created by admin on 6/21/20.
 */
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Colors from '../../constants/colors';
import Spacer from '../../components/UI/Spacer';
import RecipeList from '../../components/Recipes/RecipeList';
import { useSelector } from 'react-redux';

const RecipeFavoritesScreen = props => {
    const favRecipes = useSelector(state => state.recipes.favoriteRecipes);

    if (favRecipes.length === 0 || !favRecipes) {
        return (
            <View>
                <Text>No Favorite Recipes found. Select the heart on a recipe page to add to this list</Text>
            </View>
        );
    }

    return (
        <View>
            <RecipeList listData={favRecipes} navigation={props.navigation} />
        </View>
    );
};

RecipeFavoritesScreen.navigationOptions = {
    headerTitle: 'My Favorites'
};
;

export default RecipeFavoritesScreen;