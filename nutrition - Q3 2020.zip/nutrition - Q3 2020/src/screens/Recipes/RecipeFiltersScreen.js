import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Switch } from 'react-native';
import Colors from '../../constants/colors';
import { Feather } from '@expo/vector-icons';
import { TouchableOpacity } from 'react-native-gesture-handler';
import SecondaryButton from '../../components/UI/Buttons/SecondaryButton';
import { useDispatch } from 'react-redux';
import { setFilters } from '../../store/actions/recipes';

const FilterSwitch = props => {
    return (
        <View>
            <Text>{props.label}</Text>
            <Switch 
                value={props.state} 
                onValueChange={props.onChange}
                trackColor={{true: Colors.primary}} 
                thumbColor={Colors.tertiary}
            />
        </View>
    );
};

const RecipeFiltersScreen = props => {
    const [isGlutenFree, setIsGlutenFree] = useState(false);
    const [isLactoseFree, setIsLactoseFree] = useState(false);
    const [isVegan, setIsVegan] = useState(false);
    const [isVegetarian, setIsVegetarian] = useState(false);

    const dispatch = useDispatch();

    const saveFilters = useCallback(() => {
        const appliedFilters = {
            glutenFree: isGlutenFree,
            lactoseFree: isLactoseFree,
            vegan: isVegan,
            vegetarian: isVegetarian
        };
        dispatch(setFilters(appliedFilters));
    }, [isGlutenFree, isLactoseFree, isVegan, isVegetarian, dispatch]);

    useEffect(() => {
        props.navigation.setParams({ save: saveFilters })
    }, [saveFilters]);

    return (
        <View>
            <Text>Available Filters</Text>
            <FilterSwitch label='Gluten-free' state={isGlutenFree} onChange={newValue => setIsGlutenFree(newValue)} />
            <FilterSwitch label='Lactose-free' state={isLactoseFree} onChange={newValue => setIsLactoseFree(newValue)} />
            <FilterSwitch label='Vegan' state={isVegan} onChange={newValue => setIsVegan(newValue)} />
            <FilterSwitch label='Vegetarian' state={isVegetarian} onChange={newValue => setIsVegetarian(newValue)} />
            <SecondaryButton onPress={props.navigation.getParam('save')} >Hi</SecondaryButton>
        </View>
    );
};

RecipeFiltersScreen.navigationOptions = {
    headerTitle: 'Recipe Filters'
};

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        paddingHorizontal: 15,
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    image: {
        width: 300,
        height: 150,
        borderColor: 'black',
        borderWidth: 1,
        marginRight: 2
    },
    imageContainer: {
        flex: 1,
        alignItems: 'center',
    }
});

export default RecipeFiltersScreen;