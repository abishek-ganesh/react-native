/**
 * Created by admin on 6/21/20.
 */
import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator } from 'react-native';
import Spacer from '../../components/UI/Spacer';
import GoalItem from '../../components/Goals/GoalItem';
import PrimaryButton from '../../components/UI/Buttons/PrimaryButton';
import Colors from '../../constants/colors';
import { HeaderButtons, Item } from 'react-navigation-header-buttons';
import HeaderButton from '../../components/UI/Buttons/HeaderButtonFeather';
import { useSelector, useDispatch } from 'react-redux';
import * as goalActions from '../../store/actions/goals';
import * as Notifications from 'expo-notifications';

/*Below code is to overcome an Android warning with timer. Can remove once a solution is found:
https://github.com/facebook/react-native/issues/12981 */
/*import { YellowBox } from "react-native";
import _ from "lodash";
LogBox.ignoreWarnings(["Setting a timer"]);
const _console = _.clone(console);
console.warn = (message) => {
if (message.indexOf("Setting a timer") <= -1) {
_console.warn(message);
}
};*/
/*---------------------------------------------------*/


const GoalScreen = props => {
    

    const [isLoading, setIsLoading] = useState(false);
    const [isRefreshing, setIsRefreshing] = useState(false);
    const [error, setError] = useState();
    const goals = useSelector(state => state.goals.userGoals);
    const dispatch = useDispatch();

    const loadGoals = useCallback(async () => {
        setError(null);
        setIsRefreshing(true);
        try {
          await dispatch(goalActions.fetchGoals());
        } catch (err) {
          setError(err.message);
        }
        setIsRefreshing(false);
      }, [dispatch, setIsLoading, setError]);
    
    useEffect(() => {
        const willFocusSub = props.navigation.addListener('willFocus', loadGoals);
        return () => {
            willFocusSub.remove();
        };
    }, [loadGoals]);

    useEffect(() => {
        setIsLoading(true);
        loadGoals().then(() => {
            setIsLoading(false);
        });
    }, [dispatch, loadGoals]);

    const selectItemHandler = (id, goal, status, timeline, importance) => {
        props.navigation.navigate('GoalEdit', {
            goalId: id,
            goal: goal,
            status: status,
            timeline: timeline,
            importance: importance
        });
    };

    if (isLoading) {
        return (<View style={styles.centered}><ActivityIndicator size='large' color={Colors.primary} /></View>);
    }

    if (!isLoading && goals.length === 0) {
        return (
            <View style={styles.centered}>
                <Text>Select the plus icon to add a new nutrition-related goal!</Text>
            </View>
        );
    }

    return (
        <View style={{flex: 1}}>
            <FlatList
                onRefresh={loadGoals}
                refreshing={isRefreshing}
                data={goals}
                keyExtractor={item => item.id}
                renderItem={itemData =>
                    <GoalItem 
                        id={itemData.item.id}
                        goal={itemData.item.goal} 
                        status={itemData.item.status} 
                        timeline={itemData.item.timeline} 
                        importance={itemData.item.importance} 
                        onSelect={() => {
                            selectItemHandler(
                                itemData.item.id, 
                                itemData.item.goal, 
                                itemData.item.status, 
                                itemData.item.timeline, 
                                itemData.item.importance
                            );
                        }}
                        onRemove={() => {
                            dispatch(goalActions.deleteGoal(itemData.item.id));
                        }}
                    />
                }
            />
            
        </View>
    );
};

GoalScreen.navigationOptions = (navigationData) => {
    return {
        headerLeft: () => (
            <HeaderButtons HeaderButtonComponent={HeaderButton}>
                <Item 
                    title='Menu'
                    iconName='menu'
                    onPress={() => {navigationData.navigation.toggleDrawer()}}
                />
            </HeaderButtons>
        ),
        headerRight: () => (
            <HeaderButtons HeaderButtonComponent={HeaderButton}>
                <Item
                    title="Add Entry"
                    iconName='plus'
                    onPress={() => {navigationData.navigation.navigate('GoalEdit')}}
                />
            </HeaderButtons>
        ),
    };
}

const styles = StyleSheet.create({
    centered: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
});

export default GoalScreen;