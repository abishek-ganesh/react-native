/**
 * Created by admin on 6/21/20.
 */
//used for Goal Edit + Goal Add
import React, { useState, useReducer, useCallback, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, ScrollView, Platform, Alert, KeyboardAvoidingView, ActivityIndicator } from 'react-native';
import Input from '../../components/UI/Input';
import Spacer from '../../components/UI/Spacer';
import DeleteButton from '../../components/UI/Buttons/DeleteButton';
import { HeaderButtons, Item } from 'react-navigation-header-buttons';
import HeaderButton from '../../components/UI/Buttons/HeaderButton';
import { useSelector, useDispatch } from 'react-redux';
import * as goalActions from '../../store/actions/goals';
import Colors from '../../constants/colors';

const FORM_INPUT_UPDATE = 'FORM_INPUT_UPDATE';

const formReducer = (state, action) => {
    if (action.type === FORM_INPUT_UPDATE) {
        const updatedValues = {
            ...state.inputValues,
            [action.input]: action.value
        };
        const updatedValidities = {
            ...state.inputValidities,
            [action.input]: action.isValid
        };
        let updatedFormIsValid = true;
        for (const key in updatedValidities) {
            updatedFormIsValid = updatedFormIsValid && updatedValidities[key];
        }
        return {
            formIsValid: updatedFormIsValid,
            inputValidities: updatedValidities,
            inputValues: updatedValues
        };
    }
    return state;
};

const GoalEditScreen = props => {
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState();

    const goalId = props.navigation.getParam('goalId');
    const editedGoal = useSelector(state =>
        state.goals.userGoals.find(goal => goal.id === goalId)    
    );

    const dispatch = useDispatch();

    const [formState, dispatchFormState] = useReducer(formReducer, {
        inputValues: {
            goal: editedGoal ? editedGoal.goal : '',
            status: editedGoal ? editedGoal.status : '',
            timeline: editedGoal ? editedGoal.timeline : '',
            importance: editedGoal ? editedGoal.importance : ''
        }, 
        inputValidities: {
            goal: editedGoal ? true: false,
            status: editedGoal ? true: false,
            timeline: editedGoal ? true: false,
            importance: editedGoal ? true: false,
        }, 
        formIsValid: editedGoal ? true : false 
    });

    useEffect(() => {
        if (error) {
            Alert.alert('An error occured!', error, [{ text: 'Okay' }]);
        }
    }, [error]);

    const submitHandler = useCallback(async () => {
        if (!formState.formIsValid) {
            Alert.alert('Wrong input!', 'Please check error in the form', [
                { text: 'Okay' }
            ]);
            return;
        }
        setError(null);
        setIsLoading(true);
        try {
            if (editedGoal) {
                await dispatch(
                    goalActions.updateGoal(
                        goalId,
                        formState.inputValues.goal,
                        formState.inputValues.status,
                        formState.inputValues.timeline,
                        formState.inputValues.importance
                    )
                );
            } else {
                await dispatch(
                    goalActions.addGoal(
                        formState.inputValues.goal,
                        formState.inputValues.status,
                        formState.inputValues.timeline,
                        formState.inputValues.importance
                    )
                );
            }
            props.navigation.goBack();
        } catch (err) {
            setError(err.message);
        }
        setIsLoading(false);
    }, [dispatch, goalId, formState]);

    const deleteHandler = goalId => {
        Alert.alert('Are you sure?', 'Do you want to delete this goal?', [
            { 
                text: 'No', 
                style: 'default' 
            },
            {
                text: 'Yes',
                style: 'destructive',
                onPress: () => {
                    setIsLoading(true);
                    dispatch(goalActions.deleteGoal(goalId)); 
                    props.navigation.goBack();
                    setIsLoading(false);
                }
            }
        ]);
    };

    useEffect(() => {
        props.navigation.setParams({ submit: submitHandler });
    }, [submitHandler]);

    const inputChangeHandler = useCallback(
        (inputIdentifier, inputValue, inputValidity) => {
            dispatchFormState({
                type: FORM_INPUT_UPDATE,
                value: inputValue,
                isValid: inputValidity,
                input: inputIdentifier
            });
        },
        [dispatchFormState]
    );

    if (isLoading) {
        return (
            <View style={styles.centered}>
                <ActivityIndicator size='large' color={Colors.primary} />
            </View>
        );
    }
    
    return (
        <KeyboardAvoidingView 
            style={{flex: 1}}
            behavior='padding'
            keyboardVerticalOffset={100}
        >
            <ScrollView>
                <View style={styles.form}>
                    <Input 
                        id='goal'
                        label='Goal'
                        errorText='Please enter a valid goal!'
                        keyboardType="default"
                        autoCapitalize='sentences'
                        autoCorrect
                        returnKeyType='next'
                        onInputChange={inputChangeHandler}
                        initialValue={editedGoal ? editedGoal.goal : ''}
                        initiallyValid={!!editedGoal}
                        required
                    />
                    <Spacer />
                    <Input 
                        id='status'
                        label='Status'
                        errorText='Please enter a valid status!'
                        keyboardType='number-pad'
                        returnKeyType='next'
                        onInputChange={inputChangeHandler}
                        initialValue={editedGoal ? editedGoal.status : ''}
                        initiallyValid={!!editedGoal}
                        required
                        min={0}
                        max={5}
                    />
                    <Spacer />
                    <Input 
                        id='timeline'
                        label='Timeline'
                        errorText='Please enter a valid goal date!'
                        keyboardType="default"
                        returnKeyType='next'
                        onInputChange={inputChangeHandler}
                        initialValue={editedGoal ? editedGoal.timeline : ''}
                        initiallyValid={!!editedGoal}
                        required
                    />
                    <Spacer />
                    <Input 
                        id='importance'
                        label='Importance'
                        errorText='Please enter a valid reason!'
                        keyboardType="default"
                        autoCapitalize='sentences'
                        autoCorrect
                        returnKeyType='next'
                        onInputChange={inputChangeHandler}
                        initialValue={editedGoal ? editedGoal.importance : ''}
                        initiallyValid={!!editedGoal}
                    />
                    <Spacer />
                    <Spacer />
                    <Spacer />
                    <Spacer />
                    <Spacer />
                    {editedGoal 
                    ? <DeleteButton onPress={deleteHandler.bind(this, goalId)} >Delete Goal</DeleteButton>
                    : null
                    }
                </View>
            </ScrollView>
        </KeyboardAvoidingView>
    );
};

GoalEditScreen.navigationOptions = navData => {
    const submitFn = navData.navigation.getParam('submit');
    return {
        headerTitle: navData.navigation.getParam('goalId') 
            ? 'Edit Goal'
            : 'Add Goal',
        headerRight: () => (
            <HeaderButtons HeaderButtonComponent={HeaderButton}>
                <Item 
                    title="Save"
                    iconName={
                        Platform.OS === 'android' ? 'md-checkmark' : 'ios-checkmark'
                    }
                    onPress={submitFn}
                />
            </HeaderButtons>
        )
    };
};

const styles = StyleSheet.create({
    centered: {
        justifyContent: 'center',
        alignItems: 'center',
        flex: 1,
    },
    form: {
        flex: 1,
        margin: 20
    },
});

export default GoalEditScreen;