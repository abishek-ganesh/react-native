/**
 * Created by admin on 6/21/20.
 */
import React, { useState } from 'react';
import { View, Text, StyleSheet, Linking } from 'react-native';
import { Button, SearchBar } from 'react-native-elements';
import Colors from '../../constants/colors';
import Spacer from '../../components/UI/Spacer';
import { TouchableOpacity } from 'react-native-gesture-handler';
import SearchEntry from '../../components/Search/SearchEntry';


const SearchScreen = props => {

    const [searchQuery, setSearchQuery] = useState('');

    const onChangeSearch = query => setSearchQuery(query);


    return (
        <>
            <Spacer /><Spacer />
            <SearchBar
                placeholder="Search..."
                lightTheme={true}
                onChangeText={onChangeSearch}
                value={searchQuery}
            />
            <SearchEntry />
            <Spacer />
            <TouchableOpacity onPress={() => props.navigation.navigate('mainFlow')} ><Text style={{ color: 'grey' }}>[[temp Back button]]</Text></TouchableOpacity>
        </>
    );
};

const styles = StyleSheet.create({

});

export default SearchScreen;