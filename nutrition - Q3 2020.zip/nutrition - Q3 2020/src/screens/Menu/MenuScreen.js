/**
 * Created by admin on 6/21/20.
 */
import React, { useContext } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Button } from 'react-native-elements';
import { SafeAreaView } from 'react-navigation';
import PrimaryButton from '../../components/UI/Buttons/PrimaryButton';
import Spacer from '../../components/UI/Spacer';

const MenuScreen = props => {
    return (
        <SafeAreaView forceInset={{ top: 'always' }}>
            <Text style={{ fontSize: 48 }}>Profile Settings</Text>
            <Spacer />
            <Button title="Sign Out" />
            <PrimaryButton onPress={() => props.navigation.navigate('mainFlow')}>Back to Goals</PrimaryButton>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({

});

export default MenuScreen;