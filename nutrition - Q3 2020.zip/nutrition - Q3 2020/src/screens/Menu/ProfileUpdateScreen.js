/**
 * Created by admin on 6/21/20.
 */
import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, Picker } from 'react-native';
import DatePicker from 'react-native-datepicker'
import Spacer from '../../components/UI/Spacer';
import PrimaryButton from '../../components/UI/Buttons/PrimaryButton';
import SecondaryButton from '../../components/UI/Buttons/SecondaryButton';
import { useDispatch } from 'react-redux';
import * as profileActions from '../../store/actions/profile';

const ProfileUpdateScreen = props => {
    const userId = props.navigation.getParam('userId');
    const [fName, setFName] = useState(props.navigation.getParam('firstName'));
    const [lName, setLName] = useState(props.navigation.getParam('lastName'));
    const [email, setEmail] = useState(props.navigation.getParam('email'));
    const [dob, setDOB] = useState(props.navigation.getParam('dob'));
    const [gender, setGender] = useState(props.navigation.getParam('gender'));

    const dispatch = useDispatch();

    const fNameInputHandler = (enteredText) => {setFname(enteredText);};
    const lNameInputHandler = (enteredText) => {setLname(enteredText);};
    const emailInputHandler = (enteredText) => {setEmail(enteredText);};
    const dobInputHandler = (enteredDate) => {setDOB(enteredDate);};
    const genderInputHandler = (selectedOption) => {setGender(selectedOption);};

    
    return (
        <View style={styles.inputContainer} >
            <Text style={{ fontSize: 20 }}>First Name:</Text>
            <TextInput
                placeholder='First name...'
                autoCorrect={false}
                style={styles.input}
                onChangeText={fNameInputHandler}
                value={fName}
            />
            <Spacer />
            <Text style={{ fontSize: 20 }}>Last Name:</Text>
            <TextInput
                placeholder='Last name...'
                autoCorrect={false}
                style={styles.input}
                onChangeText={lNameInputHandler}
                value={lName}
            />
            <Spacer />
            <Text style={{ fontSize: 20 }}>Email:</Text>
            <TextInput
                placeholder='Email address...'
                autoCorrect={false}
                autoCompleteType='email'
                style={styles.input}
                onChangeText={emailInputHandler}
                value={email}
            />
            <Spacer />
            <Text style={{ fontSize: 20 }}>Date of birth:</Text>
            <DatePicker 
                date={dob}
                mode='date'
                placeholder='Select date...'
                format='MM/DD/YYYY'
                minDate='01/01/1920'
                maxDate='12/31/2021'
                confirmBtnText='Confirm'
                cancelBtnText='Cancel'
                customStyles={{
                    dateIcon: {
                      position: 'absolute',
                      left: 0,
                      top: 4,
                      marginLeft: 0
                    },
                    dateInput: {
                      marginLeft: 36,
                      width: 200
                    }
                }}
                onDateChange={dobInputHandler}
            />
            <Spacer />
            <Text style={{ fontSize: 20 }}>Gender:</Text>
            <Picker
                selectedValue={gender}
                style={{ height: 50, width: 300, borderColor: 'black', borderWidth: 1 }}
                itemStyle={{ height: 50 }}
                onValueChange={genderInputHandler}
            >
                <Picker.Item label='Male' value='Male' />
                <Picker.Item label='Female' value='Female' />
                <Picker.Item label='Non-binary' value='Non-binary' />
                <Picker.Item label='I do not wish to answer' value='None' />
            </Picker>
            <Spacer />
            <Spacer />
            <PrimaryButton 
                onPress={() => {
                    dispatch(profileActions.updateProfile(userId, fName, lName, email, dob, gender));
                    props.navigation.navigate('Goal')
                }}
            >Confirm</PrimaryButton>
            <Spacer />
            <SecondaryButton>Update Password</SecondaryButton>
        </View>
    );
};


const styles = StyleSheet.create({
    inputContainer: {
        justifyContent: 'center',
        alignItems: 'center',
        flex: 1,
    },
    input: {
        height: 40, 
        borderColor: 'gray', 
        borderWidth: 1,
        width: 300,
    },
});

export default ProfileUpdateScreen;