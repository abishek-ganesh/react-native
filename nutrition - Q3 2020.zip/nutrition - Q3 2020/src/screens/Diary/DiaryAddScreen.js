import React, { useState, useCallback, useReducer, useEffect } from 'react';
import { ScrollView, View, Button, Text, TextInput, StyleSheet, KeyboardAvoidingView } from 'react-native';
import Input from '../../components/UI/Input';
import Spacer from '../../components/UI/Spacer';
import Colors from '../../constants/colors';
import * as diaryActions from '../../store/actions/diary';
import ImagePicker from '../../components/Diary/ImagePicker';
import { useSelector, useDispatch } from 'react-redux';
import { HeaderButtons, Item } from 'react-navigation-header-buttons';
import HeaderButton from '../../components/UI/Buttons/HeaderButton';

const FORM_INPUT_UPDATE = 'FORM_INPUT_UPDATE';


const DiaryAddScreen = props => {
  const [titleValue, setTitleValue] = useState('');
  const [dateValue, setDateValue] = useState();
  const [descriptionValue, setDescriptionValue] = useState();
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
  const [selectedImage, setSelectedImage] = useState();

  const dispatch = useDispatch();

  const titleChangeHandler = text => {
    // you could add validation
    setTitleValue(text);
  };

  const dateChangeHandler = date => {
    // you could add validation
    setDateValue(date);
  };

  const descriptionChangeHandler = text => {
    // you could add validation
    setDescriptionValue(text);
  };

  const imageTakenHandler = imagePath => {
    setSelectedImage(imagePath);
  };


  const submitHandler = () => {
    dispatch(diaryActions.addDiaryMeal(titleValue, dateValue, descriptionValue, selectedImage));
    props.navigation.goBack();
  };

  return (
    <KeyboardAvoidingView 
        style={{flex: 1}}
        behavior='padding'
        keyboardVerticalOffset={100}
    >
      <ScrollView>
        <View style={styles.form}>
          <Text style={styles.label}>Title</Text>
          <TextInput
            style={styles.textInput}
            onChangeText={titleChangeHandler}
            value={titleValue}
          />
          <Text style={styles.label}>Date</Text>
          <TextInput
            style={styles.textInput}
            onChangeText={dateChangeHandler}
            value={dateValue}
          />
          <Text style={styles.label}>Description</Text>
          <TextInput
            style={styles.textInput}
            onChangeText={descriptionChangeHandler}
            value={descriptionValue}
          />
          <ImagePicker onImageTaken={imageTakenHandler} />
          <Button
            title="Save Meal"
            color={Colors.primary}
            onPress={submitHandler}
          />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

DiaryAddScreen.navigationOptions = navData => {
    const submitFn = navData.navigation.getParam('submit');
    return {
        headerTitle: 'Add Meal',
        /*headerRight: () => (
            <HeaderButtons HeaderButtonComponent={HeaderButton}>
                <Item 
                    title="Save"
                    iconName={
                        Platform.OS === 'android' ? 'md-checkmark' : 'ios-checkmark'
                    }
                    onPress={submitFn}
                />
            </HeaderButtons>
        )*/
    };
};

const styles = StyleSheet.create({
  form: {
    margin: 30
  },
  label: {
    fontSize: 18,
    marginBottom: 15
  },
  textInput: {
    borderBottomColor: '#ccc',
    borderBottomWidth: 1,
    marginBottom: 15,
    paddingVertical: 4,
    paddingHorizontal: 2
  }
});

export default DiaryAddScreen;