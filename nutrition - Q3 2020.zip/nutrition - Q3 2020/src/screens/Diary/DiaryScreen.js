/**
 * Created by admin on 6/21/20.
 */
import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator, ScrollView } from 'react-native';
import { Button } from 'react-native-elements';
import MealItem from '../../components/Diary/MealItem';
import DailyDiaryEntry from './DailyDiaryEntry';
import DateTimePickerModal from "react-native-modal-datetime-picker";
import Colors from '../../constants/colors';
import { ENTRY_DATES } from '../../data/entryDates-dummy-data';
import { HeaderButtons, Item } from 'react-navigation-header-buttons';
import HeaderButton from '../../components/UI/Buttons/HeaderButtonFeather';
import { useSelector, useDispatch } from 'react-redux';
import * as diaryActions from '../../store/actions/diary';
import { Calendar } from 'react-native-calendars';
import { RECIPE_CATEGORIES } from '../../data/recipe-dummy-data';
import RecipeCategoryTile from '../../components/Recipes/RecipeCategoryTile';
import * as Notifications from 'expo-notifications';
import Spacer from '../../components/UI/Spacer';

const DiaryScreen = props => {
    const [isLoading, setIsLoading] = useState(false);
    const [isRefreshing, setIsRefreshing] = useState(false);
    const [error, setError] = useState();
    const diaryMeals = useSelector(state => state.diaryMeals.userDiaryMeals);
    
    const dispatch = useDispatch();

    const loadDiaryMeals = useCallback(async () => {
        setError(null);
        setIsRefreshing(true);
        try {
          await dispatch(diaryActions.fetchDiaryMeals());
        } catch (err) {
          setError(err.message);
        }
        setIsRefreshing(false);
    }, [dispatch, setIsLoading, setError]);
    
    useEffect(() => {
        const willFocusSub = props.navigation.addListener('willFocus', loadDiaryMeals);
        return () => {
            willFocusSub.remove();
        };
    }, [loadDiaryMeals]);

    useEffect(() => {
        setIsLoading(true);
        loadDiaryMeals().then(() => {
            setIsLoading(false);
        });
    }, [dispatch, loadDiaryMeals]);

    if (error) {
        return (
            <View style={styles.centered}>
                <Text>An error occurred!</Text>
                <Button
                    title="Try again"
                    onPress={loadDiaryMeals}
                    color={Colors.primary}
                />
            </View>
        );
    }

    if (isLoading) {
        return (<View style={styles.centered}><ActivityIndicator size='large' color={Colors.primary} /></View>);
    }

    const handleConfirm = (date) => {
        console.warn("A date has been picked: ", date);
    };

    const renderDailyEntry = itemData => {
        return (
            <DailyDiaryEntry 
                date={itemData.item.date} 
                navigation={props.navigation}
            />
            
        );
    };

    /*<FlatList 
        data={ENTRY_DATES}
        renderItem={renderDailyEntry}
        keyExtractor={item => item.date}
    />*/

    const triggerNotificationHandler = () => {
        Notifications.scheduleNotificationAsync({
            content: {
                title: 'Need a snack? How about a handful of almonds?',
                body: 'Almonds are high in fiber and protein'
            },
            trigger: {
                seconds: 10
            },
        });
    };

    return (
        <ScrollView>
            <Calendar 
                onDayPress={(day) => {
                    props.navigation.navigate('DailyDiary', { day: day })
                }}
            />
            <Spacer />
            <Text style={{ alignSelf: 'center', fontSize: 22 }}>Recent Meals</Text>
            <FlatList
                onRefresh={loadDiaryMeals}
                refreshing={isRefreshing}
                data={diaryMeals}
                keyExtractor={item => item.id}
                numColumns={2}
                style={styles.list}
                renderItem={itemData => 
                    <MealItem 
                        image={itemData.item.image}
                        title={itemData.item.title}
                        date={itemData.item.date}
                        description={itemData.item.description}
                        onSelect={() => {
                            props.navigation.navigate('DiaryDetail', { mealId: itemData.item.id, mealTitle: itemData.item.title })
                        }}
                    />
                }
            />
            <Button 
                title="Test notifications"
                type="clear"
                onPress={triggerNotificationHandler}
                style={{justifyContent: 'flex-end'}}
            />
        </ScrollView>
    );
};

DiaryScreen.navigationOptions = (navigationData) => {
    return {
        headerLeft: () => (
            <HeaderButtons HeaderButtonComponent={HeaderButton}>
                <Item 
                    title='Menu'
                    iconName='menu'
                    onPress={() => {navigationData.navigation.toggleDrawer()}}
                />
            </HeaderButtons>
        ),
        headerRight: () => (
            <HeaderButtons HeaderButtonComponent={HeaderButton}>
                <Item
                    title="Add Entry"
                    iconName='plus'
                    onPress={() => {navigationData.navigation.navigate('DiaryAdd')}}
                />
            </HeaderButtons>
        ),
    };
}

const styles = StyleSheet.create({
    centered: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
    list: {
        alignSelf: 'center',
    },
});

export default DiaryScreen;