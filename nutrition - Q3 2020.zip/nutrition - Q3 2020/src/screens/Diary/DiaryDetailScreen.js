import React from 'react';
import { ScrollView, Image, View, Text, StyleSheet } from 'react-native';
import { useSelector } from 'react-redux';
import Colors from '../../constants/colors';
import Spacer from '../../components/UI/Spacer';
import { HeaderButtons, Item } from 'react-navigation-header-buttons';
import HeaderButtonFA from '../../components/UI/Buttons/HeaderButtonFA';

const DiaryDetailScreen = props => {
  const mealId = props.navigation.getParam('mealId');
  const selectedMeal = useSelector(state =>
    state.diaryMeals.userDiaryMeals.find(meal => meal.id === mealId)
  );

  return (
    <ScrollView contentContainerStyle={{ alignItems: 'center' }}>
      <Image style={styles.image} source={{ uri: selectedMeal.image }} />
      <Spacer />
      <Text style={{fontSize: 22}}>{selectedMeal.date}</Text>
      <Spacer />
      <Text>{selectedMeal.description}</Text>
    </ScrollView>
  );
};

DiaryDetailScreen.navigationOptions = navData => {
    return {
        headerTitle: navData.navigation.getParam('mealTitle')
          ? navData.navigation.getParam('mealTitle')
          : 'Meal Details',
        headerRight: () => (
          <HeaderButtons HeaderButtonComponent={HeaderButtonFA}>
              <Item 
                  title='Share'
                  iconName='share'
              />
          </HeaderButtons>
        )
    };
};

const styles = StyleSheet.create({
  image: {
    height: '35%',
    minHeight: 300,
    width: '100%',
    backgroundColor: '#ccc'
  },
  addressContainer: {
    padding: 20
  },
  address: {
    color: Colors.primary,
    textAlign: 'center'
  },
});

export default DiaryDetailScreen;
