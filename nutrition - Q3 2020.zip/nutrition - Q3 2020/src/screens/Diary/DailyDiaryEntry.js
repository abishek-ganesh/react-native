import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator } from 'react-native';
import MealItem from '../../components/Diary/MealItem';
import DateTimePickerModal from "react-native-modal-datetime-picker";
import Colors from '../../constants/colors';
import { useSelector, useDispatch } from 'react-redux';
import * as diaryActions from '../../store/actions/diary';

const DailyDiaryEntry = props => {
    const [isLoading, setIsLoading] = useState(false);
    const [isRefreshing, setIsRefreshing] = useState(false);
    const [error, setError] = useState();
    const diaryMeals = useSelector(state => state.diaryMeals.userDailyDiaryMeals);
    const dispatch = useDispatch();
    {console.log(diaryMeals)};
    const datePull = props.date;

    const loadDiaryMeals = diaryMeals.filter(meal => meal.date === datePull);

    /*const loadDiaryMeals = useCallback(async () => {
        setError(null);
        setIsRefreshing(true);
        try {
          await dispatch(diaryActions.fetchDailyDiaryMeals(props.date));
        } catch (err) {
          setError(err.message);
        }
        setIsRefreshing(false);
    }, [dispatch, setIsLoading, setError]);
    
    useEffect(() => {
        const willFocusSub = props.navigation.addListener('willFocus', loadDiaryMeals);
        return () => {
            willFocusSub.remove();
        };
    }, [loadDiaryMeals]);

    useEffect(() => {
        setIsLoading(true);
        loadDiaryMeals().then(() => {
            setIsLoading(false);
        });
    }, [dispatch, loadDiaryMeals]);

    if (isLoading) {
        return (<View style={styles.centered}><ActivityIndicator size='large' color={Colors.primary} /></View>);
    }

    const handleConfirm = (date) => {
        console.warn("A date has been picked: ", date);
    };

    const renderDailyEntry = itemData => {
        return (
            <MealItem 
                image={itemData.item.image}
                title={itemData.item.title}
                date={itemData.item.date}
                description={itemData.item.description}
                onSelect={() => {
                    props.navigation.navigate('DiaryDetail', { mealId: itemData.item.id, mealTitle: itemData.item.title })
                }}
            />
        );
    };*/

    return (
        <View>
            <Text>{props.date}</Text>
            <FlatList
                onRefresh={loadDiaryMeals}
                refreshing={isRefreshing}
                data={diaryMeals}
                keyExtractor={item => item.id}
                renderItem={itemData => 
                    <MealItem 
                        image={itemData.item.image}
                        title={itemData.item.title}
                        date={props.date}
                        description={itemData.item.description}
                        onSelect={() => {
                            props.navigation.navigate('DiaryDetail', { mealId: itemData.item.id, mealTitle: itemData.item.title })
                        }}
                    />
                }
            />
            
        </View>
    );
};

const styles = StyleSheet.create({
    centered: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
});

export default DailyDiaryEntry;