import Goal from '../../models/goal';
import * as Notifications from 'expo-notifications';
import * as Permissions from 'expo-permissions';

export const ADD_GOAL = 'ADD_GOAL';
export const UPDATE_GOAL = 'UPDATE_GOAL';
export const DELETE_GOAL = 'DELETE_GOAL';
export const SET_GOALS = 'SET_GOALS';

export const fetchGoals = () => {
    return async (dispatch, getState) => {
        const userId = getState().auth.userId;
        console.log('fetch goals getState =');
        console.dir(getState());
        try{
            const response = await fetch('https://nutrition-application.firebaseio.com/goals.json');

            if (!response.ok) {
                throw new Error('Something went wrong!');
            }

            const resData = await response.json();
            const loadedGoals = [];
            for (const key in resData) {
                loadedGoals.push(
                    new Goal(
                        key, 
                        resData[key].ownerId, 
                        resData[key].goal, 
                        resData[key].status, 
                        resData[key].timeline, 
                        resData[key].importance
                    )
                );
            }
            dispatch({ type: SET_GOALS, goals: loadedGoals, userGoals: loadedGoals.filter(g => g.ownerId === userId) });
        } catch (err) {
            throw err;
        }  
    };
};

export const addGoal = (goal, status, timeline, importance) => {
    return async (dispatch, getState) => {
        let pushToken;
        let statusObj = await Permissions.getAsync(Permissions.NOTIFICATIONS);
        if (statusObj.status !== 'granted') {
            statusObj = await Permissions.askAsync(Permissions.NOTIFICATIONS);
        }
        if (statusObj.status !== 'granted') {
            pushToken = null;
        } else {
            pushToken = (await Notifications.getExpoPushTokenAsync()).data;
        }
        const token = getState().auth.token;
        const userId = getState().auth.userId;
        const dateSet = new Date();
        const complete = 'false';
        const response = await fetch(`https://nutrition-application.firebaseio.com/goals.json?auth=${token}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                goal,
                status,
                timeline,
                importance,
                dateSet: dateSet.toISOString(),
                complete,
                ownerId: userId,
                ownerPushToken: pushToken
            })
        });

        const resData = await response.json();


        dispatch ({
            type: ADD_GOAL,
            goalData: {
                id: resData.name,
                goal,
                status,
                timeline,
                importance,
                dateSet,
                complete,
                ownerId: userId
            }
        });
    };
};

export const updateGoal = (id, goal, status, timeline, importance) => {
    return async (dispatch, getState) => {
        const token = getState().auth.token;
        const response = await fetch(
            `https://nutrition-application.firebaseio.com/goals/${id}.json?auth=${token}`,
            {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    goal,
                    status,
                    timeline,
                    importance
                })
            }
        );

        if (!response.ok) {
            throw new Error('Something went wrong!');
        }

        dispatch({
            type: UPDATE_GOAL,
            gid: id,
            goalData: {
                goal,
                status,
                timeline,
                importance
            }
        });
    };
};

export const deleteGoal = goalId => {
    return async (dispatch, getState) => {
        const token = getState().auth.token;
        const response = await fetch(
            `https://nutrition-application.firebaseio.com/goals/${goalId}.json?auth=${token}`,
            {
                method: 'DELETE'
            }
        );
        
        if (!response.ok) {
            throw new Error('Something went wrong!');
        }

        dispatch({ type: DELETE_GOAL, gid: goalId });
    };
    
};