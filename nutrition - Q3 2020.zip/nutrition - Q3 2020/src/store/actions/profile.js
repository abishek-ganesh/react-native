export const CREATE_PROFILE = 'CREATE_PROFILE';
export const UPDATE_PROFILE = 'UPDATE_PROFILE';
export const DELETE_PROFILE = 'DELETE_PROFILE';

export const createProfile = (fName, lName, email, dob, gender, pw) => {
    return {
        type: CREATE_PROFILE,
        profileData: {
            fName,
            lName,
            email,
            dob,
            gender,
            pw
        }
    };
};

export const updateProfile = (userId, fName, lName, email, dob, gender, pw) => {
    return {
        type: UPDATE_PROFILE,
        uid: userId,
        profileData: {
            fName,
            lName,
            email,
            dob,
            gender,
            pw
        }
    };
};

export const deleteProfile = id => {
    return { type: DELETE_PROFILE, pid: id };
}