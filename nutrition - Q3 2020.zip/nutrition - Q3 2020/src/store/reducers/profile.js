import PROFILES from '../../data/profile-dummy-data';
import Profile from '../../models/profile';
import { CREATE_PROFILE, UPDATE_PROFILE, DELETE_PROFILE } from '../actions/profile';

const initialState = {
    userProfile: PROFILES.filter(prof => prof.userId === '001')
};

export default (state = initialState, action) => {
    switch (action.type) {
        case CREATE_PROFILE:
            const newProfile = new Profile(
                new Date().toString(),
                action.profileData.fName,
                action.profileData.lName,
                action.profileData.email,
                action.profileData.dob,
                action.profileData.gender,
                action.profileData.pw
            );
            return {
                ...state,
                userProfile: state.userProfile.concat(newProfile)
            };
        case UPDATE_PROFILE:
            const profileIndex = state.userProfile.findIndex(
                prof => prof.userId === action.uid
            );
            const updatedProfile = new Profile(
                action.uid,
                action.profileData.fName,
                action.profileData.lName,
                action.profileData.email,
                action.profileData.dob,
                action.profileData.gender,
                action.profileData.pw
            );
            const updatedUserProfiles = [...state.userProfile];
            updatedUserProfiles[profileIndex] = updatedProfile;
            return {
                ...state,
                userProfile: updatedUserProfiles
            };
        case DELETE_PROFILE:
            return {
                ...state,
                userProfile: state.userProfile.filter(
                    prof => prof.userId !== action.uid
                )
            };
    }
    return state;
};