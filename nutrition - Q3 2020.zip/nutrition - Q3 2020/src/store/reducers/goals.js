import { SET_GOALS, ADD_GOAL, UPDATE_GOAL, DELETE_GOAL } from '../actions/goals';
import Goal from '../../models/goal';

const initialState = {
    userGoals: []
};

export default (state = initialState, action) => {
    switch (action.type) {
        case SET_GOALS: 
            return {
                userGoals: action.userGoals
            };
        case ADD_GOAL:
            const newGoal = new Goal(
                action.goalData.id,
                action.goalData.ownerId,
                action.goalData.goal,
                action.goalData.status,
                action.goalData.timeline,
                action.goalData.importance
            );
            return {
                ...state,
                userGoals: state.userGoals.concat(newGoal)
            };
        case UPDATE_GOAL:
            const goalIndex = state.userGoals.findIndex(
                goal => goal.id === action.gid
            );
            const updatedGoal = new Goal(
                action.gid,
                state.userGoals[goalIndex].userId,
                action.goalData.goal,
                action.goalData.status,
                action.goalData.timeline,
                action.goalData.importance
            );
            const updatedUserGoals = [...state.userGoals];
            updatedUserGoals[goalIndex] = updatedGoal;
            return {
                ...state,
                userGoals: updatedUserGoals
            };
        case DELETE_GOAL:
            return {
                ...state,
                userGoals: state.userGoals.filter(
                    goal => goal.id !== action.gid
                )
            };
    }
    return state;
};