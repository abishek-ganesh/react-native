import Profile from '../models/profile';

const PROFILES = [
    new Profile('001', 'Abishek', 'Ganesh', 'admin@admin.com', '09/22/2009', 'Male', 'password123')
];

export default PROFILES;