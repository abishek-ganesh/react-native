import EntryDate from '../models/entryDate';

export const ENTRY_DATES = [
    new EntryDate('1/7/2020'),
    new EntryDate('1/2/2020')
];

export default ENTRY_DATES;