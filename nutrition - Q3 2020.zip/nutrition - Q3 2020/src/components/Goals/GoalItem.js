/**
 * Created by admin on 6/23/20.
 */
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TouchableNativeFeedback, Platform } from 'react-native';
import Spacer from '../UI/Spacer';
import Card from '../UI/Card';
import Colors from '../../constants/colors';

const GoalItem = props => {
    let TouchableCmp = TouchableOpacity;

    if (Platform.OS === 'android' && Platform.Version >= 21) {
        TouchableCmp = TouchableNativeFeedback;
    }

    return (
        <Card style={styles.container}>
            <View style={styles.touchable}>
                <TouchableCmp onPress={props.onSelect} useForeground>
                    <View>
                        <View style={styles.details}>
                            <Text style={styles.goal}>{props.goal}</Text>
                            <Spacer />
                            <Text style={styles.status}>{props.status} / 5</Text>
                            <Spacer />
                            <Text style={styles.timeline}>Goal date: {props.timeline}</Text>
                            <Spacer />
                            <Text style={styles.price}>{props.importance}</Text>
                        </View>
                        <View style={styles.actions}>
                            {props.children}
                        </View>
                    </View>
                </TouchableCmp>
            </View>
        </Card>
    );
};

const styles = StyleSheet.create({
    container: {
        height: 200,
        margin: 20
    },
    touchable: {
        borderRadius: 10,
        overflow: 'hidden'
    },
    details: {
        alignItems: 'center',
        padding: 10
    },
    goal: {
        fontSize: 26,
        marginVertical: 2
    },
    timeline: {
        fontSize: 18,
        marginVertical: 2
    },
    status: {
        fontSize: 24,
        marginVertical: 2,
        color: Colors.primary,
        fontWeight: 'bold'
    },
    importance: {
        fontSize: 14,
        color: '#888'
    },
    actions: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 20
    },
});

export default GoalItem;