import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity, Linking } from 'react-native';
import Spacer from '../UI/Spacer';
import { Feather } from '@expo/vector-icons';

const SearchEntry = props => {
    return (
        <View>
            <ScrollView>
                <Spacer />
                <TouchableOpacity style={styles.facts} onPress={() => Linking.openURL('https://nutritionfacts.org/video/omnivore-vs-vegan-nutrient-deficiencies-2/')}>
                    <Text style={{ fontSize: 18, fontWeight: 'bold' }}>Nutrient deficiencies: Vegan v Omnivore{"\n"}</Text>
                    <Text>Average vegan diets tend to be deficient in three nutrients, whereas average omnivores tend, unfortunately, to be deficient in seven.{"\n"}</Text>
                </TouchableOpacity>
                <Spacer />
                <TouchableOpacity style={styles.facts} onPress={() => Linking.openURL('https://nutritionfacts.org/video/thousands-of-vegans-studied/')}>
                    <Text style={{ fontSize: 18, fontWeight: 'bold' }}>Thousands of Vegans Studied{"\n"}</Text>
                    <Text>The first study of thousands of vegans is released. It compares their body mass index to that of vegetarians, flexitarians, and omnivores.{"\n"}</Text>
                </TouchableOpacity>
                <Spacer />
                <TouchableOpacity style={styles.facts} onPress={() => Linking.openURL('https://www.reddit.com/r/vegan/')}>
                    <Text style={{ fontSize: 18, fontWeight: 'bold', color: 'blue' }}>Reddit thread: /r/Vegan{"\n"}</Text>
                    <Text style={{ color: 'blue' }}>This is a place for people who are vegans or interested in veganism to share links, ideas, or recipes.{"\n"}</Text>
                </TouchableOpacity>
            </ScrollView>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        paddingHorizontal: 15,
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    image: {
        width: 400,
        height: 150,
        borderColor: 'black',
        borderWidth: 1,
        marginRight: 2
    },
    imageContainer: {
        flex: 1,
        alignItems: 'center',
    },
    facts:{
        alignSelf: 'center',
        width: "80%",
        borderBottomColor: '#D0D0D0',
        borderBottomWidth: 1,
    }
});

export default SearchEntry;