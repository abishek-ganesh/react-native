import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';
import Colors from '../../constants/colors';

const MealItem = props => {
  return (
    <TouchableOpacity onPress={props.onSelect}>
      <Image style={styles.image} source={{ uri: props.image }} />
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  image: {
    width: 150,
    height: 150,
    margin: 10,
    borderRadius: 5,
    backgroundColor: '#ccc',
    borderColor: 'black',
    borderWidth: 1
  },
  address: {
    color: '#666',
    fontSize: 16
  }
});

export default MealItem;
