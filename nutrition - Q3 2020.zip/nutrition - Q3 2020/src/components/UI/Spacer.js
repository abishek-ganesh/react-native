/**
 * Created by admin on 6/20/20.
 */
// Job is to provide spacing between react-native elements
import React from 'react';
import { View, StyleSheet } from 'react-native';

const Spacer = ({ children }) => {
    return <View style={styles.spacer}>{children}</View>;
};

const styles = StyleSheet.create({
    spacer: {
        margin: 8
    }
});

export default Spacer;