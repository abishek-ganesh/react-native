import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';

const EditButton = (props) => {
    return (
        <TouchableOpacity onPress={props.onPress} activeOpacity={0.8}>
            <View style={styles.button}>
                <FontAwesome 
                    name="pencil" 
                    size={20} 
                    color='#D0D0D0' 
                />
            </View>
        </TouchableOpacity>
        
    );
};

const styles = StyleSheet.create({
    button: {
        alignSelf: 'flex-end', 
        justifyContent: 'flex-start',
        marginTop: 7
    },
});

export default EditButton;