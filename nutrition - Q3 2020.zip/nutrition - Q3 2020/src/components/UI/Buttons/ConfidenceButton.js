import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TouchableHighlight } from 'react-native';
import Colors from '../../../constants/colors';
import Spacer from '../Spacer';

const ConfidenceButton = () => {

    return (
        <View style={styles.container} >
            <TouchableHighlight style={styles.selectedButton}>
                <Text style={styles.buttonText}>1</Text>
            </TouchableHighlight>
            <Spacer />
            <TouchableHighlight style={styles.button}>
                <Text style={styles.buttonText}>2</Text>
            </TouchableHighlight>
            <Spacer />
            <TouchableHighlight style={styles.button}>
                <Text style={styles.buttonText}>3</Text>
            </TouchableHighlight>
            <Spacer />
            <TouchableHighlight style={styles.button}>
                <Text style={styles.buttonText}>4</Text>
            </TouchableHighlight>
            <Spacer />
            <TouchableHighlight style={styles.button}>
                <Text style={styles.buttonText}>5</Text>
            </TouchableHighlight>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        paddingHorizontal: 15,
        alignSelf: 'center'
    },
    button: {
        paddingVertical: 1,
        paddingHorizontal: 1,
        marginHorizontal: 1,
        width: 40,
        height: 40,
        alignSelf: 'center',
        borderWidth: 2,
        borderRadius: 20,
        borderColor: 'black',
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.23,
        shadowRadius: 2.62,
        elevation: 4,
        
    },
    selectedButton: {
        backgroundColor: Colors.primary,
        paddingVertical: 1,
        paddingHorizontal: 1,
        marginHorizontal: 1,
        width: 40,
        height: 40,
        alignSelf: 'center',
        borderWidth: 2,
        borderRadius: 20,
        borderColor: 'black',
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.23,
        shadowRadius: 2.62,
        elevation: 4,
        
    },
    buttonText: {
        color: 'black',
        alignSelf: 'center',
        fontSize: 25
    }
});

export default ConfidenceButton;