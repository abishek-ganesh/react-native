import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import Colors from '../../../constants/colors';

const DeleteButton = (props) => {
    return (
        <TouchableOpacity onPress={props.onPress} >
            <View style={styles.button}>
                <Text style={styles.buttonText}>{props.children}</Text>
            </View>
        </TouchableOpacity>
    );
};

const styles = StyleSheet.create({
    button: {
        backgroundColor: '#cc0000',
        paddingVertical: 8,
        paddingHorizontal: 10,
        marginHorizontal: 1,
        width: 150,
        alignSelf: 'center',
        borderWidth: 2,
        borderRadius: 8,
        borderColor: Colors.tertiary,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.23,
        shadowRadius: 2.62,
        elevation: 4,
        
    },
    buttonText: {
        color: Colors.tertiary,
        alignSelf: 'center'
    }
});
export default DeleteButton;