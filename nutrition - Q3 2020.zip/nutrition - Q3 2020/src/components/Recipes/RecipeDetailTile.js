import React from 'react';
import { View, Text, StyleSheet, ImageBackground } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import Colors from '../../constants/colors';

const RecipeDetailTile = props => {
    return (
        <TouchableOpacity onPress={props.onSelectRecipe} style={styles.gridItem} >
                <ImageBackground 
                    source={{uri: props.imageUrl}}
                    style={styles.image}
                    resizeMode="cover"
                >
                    <View style={styles.details}>
                        <Text style={styles.text} numberOfLines={1}>{props.title}</Text>
                        <Text style={styles.text}>{props.duration}m  Health Score:{props.healthScore}</Text>
                    </View>
                </ImageBackground>
        </TouchableOpacity> 
    );
};

const styles = StyleSheet.create({
    gridItem: {
        flex: 1,
        margin: 20,
        width: "90%",
        height: 150,
        alignItems: 'center',
        backgroundColor: Colors.tertiary,
        borderWidth: 1,
        borderRadius: 20,
        shadowColor: 'black',
        shadowOpacity: 0.26,
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 10,
        elevation: 3,
        overflow: 'hidden'
    },
    image: {
        width: '100%',
        height: '100%',
        borderColor: 'black',
        borderWidth: 1,
        borderRadius: 10,
    },
    details: {
        backgroundColor: 'rgba(0,0,0,0.5)',
        alignSelf: 'center',
        width: '100%',
        paddingVertical: 2,
    },
    text: {
        fontSize: 14, 
        color:'white', 
        alignSelf:'center',
    },
});

export default RecipeDetailTile;