import React from 'react';
import { View, Text, StyleSheet, ImageBackground } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import PrimaryButton from '../UI/Buttons/PrimaryButton';
import Colors from '../../constants/colors'

const RecipeCategoryTile = props => {
    return (
        <TouchableOpacity onPress={props.onSelectCategory} style={styles.gridItem} >
            <ImageBackground 
                source={{uri: props.image}}
                style={styles.image}
                resizeMode="cover"
            >
                <View style={styles.title}>
                    <Text style={styles.text} numberOfLines={1}>{props.title}</Text>
                </View>
            </ImageBackground>
        </TouchableOpacity>
    );
};

const styles = StyleSheet.create({
    gridItem: {
        flex: 1,
        margin: 20,
        backgroundColor: Colors.tertiary,
        width: 160,
        height: 160,
        alignItems: 'center',
        borderWidth: 1,
        borderRadius: 20,
        shadowColor: 'black',
        shadowOpacity: 0.26,
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 10,
        elevation: 3,
        overflow: 'hidden'
    },
    image: {
        width: '100%',
        height: '100%',
        borderColor: 'black',
        borderWidth: 1,
        borderRadius: 10,
    },
    title: {
        backgroundColor: 'rgba(0,0,0,0.5)',
        alignSelf: 'center',
        width: '100%',
        paddingVertical: 4,
    },
    text: {
        fontSize: 18, 
        color:'white', 
        alignSelf:'center',
    },
});

export default RecipeCategoryTile;