import React from 'react';
import { View, FlatList, StyleSheet } from 'react-native';
import RecipeDetailTile from './RecipeDetailTile';
import { useSelector } from 'react-redux'; // used to get favorite status

const RecipeList = props => {
    const favoriteRecipes = useSelector(state => state.recipes.favoriteRecipes);

    const renderRecipeItem = itemData => {
        const isFavorite = favoriteRecipes.some(recipe => recipe.id === itemData.item.id);
        return (
            <RecipeDetailTile 
                title={itemData.item.title}
                imageUrl={itemData.item.imageUrl}
                duration={itemData.item.duration}
                healthScore={itemData.item.healthScore}
                onSelectRecipe={() => {
                    props.navigation.navigate(
                        'RecipeDetail',
                        {
                            recipeId: itemData.item.id,
                            recipeTitle: itemData.item.title,
                            isFav: isFavorite
                        }
                    );
                }}
            />
        );
    };

    return (
        <View style={styles.list}>
            <FlatList 
                data={props.listData}
                renderItem={renderRecipeItem}
            />
        </View>
    );
};

const styles = StyleSheet.create({
    list: {
        flexDirection: 'row',
        paddingHorizontal: 15,
        alignItems: 'center',
        justifyContent: 'space-between',
    }
});

export default RecipeList;