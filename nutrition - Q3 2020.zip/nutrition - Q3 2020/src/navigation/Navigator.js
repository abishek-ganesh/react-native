import React from 'react';
import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import { createDrawerNavigator, DrawerNavigatorItems } from 'react-navigation-drawer';
import StartupScreen from '../screens/StartupScreen';
import AuthScreen from '../screens/Auth/AuthScreen';
import GoalScreen from '../screens/Goals/GoalScreen';
import GoalEditScreen from '../screens/Goals/GoalEditScreen';
import DiaryScreen from '../screens/Diary/DiaryScreen';
import DiaryAddScreen from '../screens/Diary/DiaryAddScreen';
import DiaryDetailScreen from '../screens/Diary/DiaryDetailScreen';
import DailyDiaryEntry from '../screens/Diary/DailyDiaryEntry';
import RecipeHomeScreen from '../screens/Recipes/RecipeHomeScreen';
import RecipeDetailScreen from '../screens/Recipes/RecipeDetailScreen';
import RecipeFavoritesScreen from '../screens/Recipes/RecipeFavoritesScreen';
import RecipeCategoryScreen from '../screens/Recipes/RecipeCategoryScreen';
import RecipeFiltersScreen from '../screens/Recipes/RecipeFiltersScreen';
import SearchScreen from '../screens/Search/SearchScreen';
import ProfileUpdateScreen from '../screens/Menu/ProfileUpdateScreen';
import { FontAwesome, MaterialCommunityIcons } from '@expo/vector-icons';
import { View, Platform, Dimensions, SafeAreaView, Button } from 'react-native';
import Colors from '../constants/colors';
import { HeaderButtons, Item } from 'react-navigation-header-buttons';
import HeaderButton from '../components/UI/Buttons/HeaderButtonFeather';
import { useDispatch } from 'react-redux';
import * as authActions from '../store/actions/auth';

const defaultNavOptions = {
    headerStyle: {
      backgroundColor: Colors.primary
    },
    headerTintColor: Colors.tertiary,
};

const goalFlow = createStackNavigator({
    Goal: GoalScreen,
    GoalEdit: GoalEditScreen
},{
    defaultNavigationOptions: ({ navigation }) => ({
        headerTitle: 'My Goals',
        headerStyle: {
            backgroundColor: Colors.primary,
        },
        headerTintColor: Colors.tertiary,
        /*headerRight: () => (
            <HeaderButtons HeaderButtonComponent={HeaderButton}>
                <Item 
                    title='Search'
                    iconName='search'
                    onPress={() => navigation.navigate('Search')}
                />
            </HeaderButtons>
        )*/
    })
});
goalFlow.navigationOptions = {
    title: 'Goals',
    tabBarIcon: <FontAwesome name="dashboard" size={25}/>
};

const diaryFlow = createStackNavigator({
    Diary: DiaryScreen,
    DiaryAdd: DiaryAddScreen,
    DiaryDetail: DiaryDetailScreen,
    DailyDiary: DailyDiaryEntry
},{
    defaultNavigationOptions: ({ navigation }) => ({
        headerTitle: 'My Diary',
        headerStyle: {
            backgroundColor: Colors.primary,
        },
        headerTintColor: Colors.tertiary,
        /*headerLeft: () => (
            <HeaderButtons HeaderButtonComponent={HeaderButton}>
                <Item 
                    title='Menu'
                    iconName='menu'
                    onPress={() => {navigation.toggleDrawer()}}
                />
            </HeaderButtons>
        ),*/
        /*headerRight: () => (
            <HeaderButtons HeaderButtonComponent={HeaderButton}>
                <Item 
                    title='Search'
                    iconName='search'
                    onPress={() => navigation.navigate('Search')}
                />
            </HeaderButtons>
        )*/
    })
});
diaryFlow.navigationOptions = {
    title: 'Diary',
    tabBarIcon: <FontAwesome name="pencil-square-o" size={25}/>,
};


const recipeFlow = createStackNavigator({
    RecipeHome: RecipeHomeScreen,
    RecipeCategory: RecipeCategoryScreen,
    RecipeDetail: RecipeDetailScreen,
    RecipeFavorites: RecipeFavoritesScreen,
    RecipeFilters: RecipeFiltersScreen
},{
    defaultNavigationOptions: ({ navigation }) => ({
        headerTitle: 'Recipes',
        headerStyle: {
            backgroundColor: Colors.primary,
        },
        headerTintColor: Colors.tertiary,
        headerRight: () => (
            <HeaderButtons HeaderButtonComponent={HeaderButton}>
                <Item 
                    title='Search'
                    iconName='search'
                    onPress={() => navigation.navigate('Search')}
                />
            </HeaderButtons>
        )
    })
});
recipeFlow.navigationOptions = {
    title: 'Recipes',
    tabBarIcon: <MaterialCommunityIcons name="food-fork-drink" size={25}/>
};

;

//-----------------------------------------------------
const homeNavigator = createBottomTabNavigator({
        goalFlow,
        diaryFlow,
        recipeFlow
    },{
        tabBarOptions: {
            activeTintColor: Colors.primary,
            activeBackgroundColor: Colors.primaryTransparent,
            showLabel: false,
        },
        initialRouteName: 'goalFlow'
    }
);

const userNavigator = createDrawerNavigator(
    {
        home: {screen: homeNavigator, navigationOptions: {
            drawerLabel: 'Home'
        }},
        ProfileUpdate: {screen: ProfileUpdateScreen, navigationOptions: {
            drawerLabel: 'Profile'
        }},
    },{
        contentOptions: {
            activeTintColor: Colors.primary,
        },
        contentComponent: props => {
            const dispatch = useDispatch();
            return (
                <View style={{flex: 1, paddingTop: 20}}>
                    <SafeAreaView forceInset={{ top: 'always', horizontal: 'never' }}>
                        <DrawerNavigatorItems {...props} />
                        <Button 
                            title='Logout'
                            color={Colors.primary}
                            onPress={() => {dispatch(authActions.logout());}}
                        />
                    </SafeAreaView>
                </View>
            );
        }
    }
);

const authNavigator = createStackNavigator(
    {Auth: AuthScreen},
    {defaultNavigationOptions: defaultNavOptions}
);

const mainNavigator = createSwitchNavigator({
    Startup: StartupScreen,
    Auth: authNavigator,
    User: userNavigator
},{
    initialRouteName: 'Startup'
}
);



export default createAppContainer(mainNavigator);

