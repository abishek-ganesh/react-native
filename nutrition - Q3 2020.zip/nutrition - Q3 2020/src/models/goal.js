import moment from 'moment';

class Goal {
    constructor(id, ownerId, goal, status, timeline, importance, dateSet, complete) {
        this.id = id;
        this.ownerId = ownerId;
        this.goal = goal;
        this.status = status;
        this.timeline = timeline;
        this.importance = importance;
        this.dateSet = dateSet;
        this.complete = complete;
    }

    get readableTimeline() {
        return moment(this.timeline).format('MMMM DD YYYY');
    }
    get readableDateSet() {
        return moment(this.dateSet).format('MMMM DD YYYY');
    }
}

export default Goal;