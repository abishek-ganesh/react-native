class Profile {
    constructor(ownerId, fName, lName, email, dob, gender, pw) {
        this.ownerId = ownerId;
        this.fName = fName;
        this.lName = lName;
        this.email = email;
        this.dob = dob;
        this.gender = gender;
        this.pw = pw;
    }
}

export default Profile;