import moment from 'moment';

class EntryDate {
    constructor(date) {
        this.date = date;
    }

    get readableDate() {
        return moment(this.date).format('MMMM DD YYYY');
    }
}

export default EntryDate;