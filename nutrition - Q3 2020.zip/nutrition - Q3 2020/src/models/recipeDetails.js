
class RecipeDetails {
    constructor(id, categoryIds, title, affordability, complexity, imageUrl, duration, ingredients, instructions, healthScore, nutritionFacts, isGlutenFree, isVegan, isVegetarian, isLactoseFree) {
        this.id = id;
        this.categoryIds = categoryIds;
        this.title = title;
        this.affordability = affordability;
        this.healthScore = healthScore;
        this.complexity = complexity;
        this.duration = duration;
        this.imageUrl = imageUrl;
        this.nutritionFacts = nutritionFacts;
        this.ingredients = ingredients;
        this.instructions = instructions;
        this.isGlutenFree = isGlutenFree;
        this.isVegan = isVegan;
        this.isVegetarian = isVegetarian;
        this.isLactoseFree = isLactoseFree;
    }
}

export default RecipeDetails;