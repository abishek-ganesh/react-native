class RecipeCategory {
    constructor(id, title, color, image) {
        this.id = id;
        this.title = title;
        this.color = color;
        this.image = image;
    }
}

export default RecipeCategory;