import moment from 'moment';

class DiaryEntry {
    constructor(id, ownerId, title, date, description, image/*, address, lat, lng*/) {
        this.id = id;
        this.ownerId = ownerId;
        this.title = title;
        this.date = date;
        this.description = description;
        this.image = image;
        /*this.address = address;
        this.lat = lat;
        this.lng = lng;*/
    }

    get readableDate() {
        return moment(this.date).format('MMMM DD YYYY');
    }
}

export default DiaryEntry;