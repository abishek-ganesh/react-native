import { StyleSheet } from 'react-native';

export default StyleSheet.create({
    title: {
        fontSize: 18
    },
    bodyText: {
        color: 'red'
    }
});